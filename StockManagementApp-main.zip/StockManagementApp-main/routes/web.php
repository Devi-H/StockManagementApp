<?php

use App\Http\Controllers\CategoryController;
use App\Http\Controllers\LogController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::view('/', 'welcome');

Route::view('dashboard', 'dashboard')
    ->middleware(['auth', 'verified', 'role:Super Admin|Admin'])
    ->name('dashboard');

Route::middleware(['auth', 'verified', 'role:Super Admin|Admin|Employee'])->group(function () {
    Route::controller(ProductController::class)->group(function () {
        Route::get('/products', 'index')->name('products');
        Route::get('/products/edit/{id}', 'editAsEmployee');
        Route::post('/products/edit/{id}', 'updateAsEmployee');
    });
});

Route::middleware(['auth', 'verified', 'role:Super Admin|Admin'])->group(function () {
    Route::controller(ProductController::class)->group(function () {
        Route::get('/dashboard/products', 'index');
        Route::get('/dashboard/products/add-product', 'create');
        Route::post('/dashboard/products/add-product', 'store');
        Route::get('/dashboard/products/{id}', 'show');
        Route::get('/dashboard/products/edit/{id}', 'edit');
        Route::post('/dashboard/products/edit/{id}', 'update');
        Route::get('/dashboard/products/remove/{id}', 'destroy');
    });

    Route::controller(OrderController::class)->group(function () {
        Route::get('/dashboard/orders', 'index');
        Route::get('/dashboard/orders/add-order', 'create');
        Route::post('/dashboard/orders/add-order', 'store');
        Route::get('/dashboard/orders/{id}', 'show');
        Route::get('/dashboard/orders/edit/{id}', 'edit');
        Route::post('/dashboard/orders/edit/{id}', 'update');
        Route::post('/dashboard/orders/remove/{id}', 'destroy');
    });

    Route::controller(CategoryController::class)->group(function () {
        Route::get('/dashboard/categories', 'index');
        Route::get('/dashboard/categories/add-category', 'create');
        Route::post('/dashboard/categories/add-category', 'store');
        Route::get('/dashboard/categories/{id}', 'show');
        Route::get('/dashboard/categories/edit/{id}', 'edit');
        Route::post('/dashboard/categories/edit/{id}', 'update');
        Route::post('/dashboard/categories/remove', 'destroy');
        Route::post('/dashboard/categories/remove/{id}', 'destroy');
    });

    Route::controller(SupplierController::class)->group(function () {
        Route::get('/dashboard/suppliers', 'index');
        Route::get('/dashboard/suppliers/add-supplier', 'create');
        Route::post('/dashboard/suppliers/add-supplier', 'store');
        Route::get('/dashboard/suppliers/{id}', 'show');
        Route::get('/dashboard/suppliers/edit/{id}', 'edit');
        Route::post('/dashboard/suppliers/edit/{id}', 'update');
        Route::post('/dashboard/suppliers/remove', 'destroy');
        Route::post('/dashboard/suppliers/remove/{id}', 'destroy');
    });

    Route::controller(UserController::class)->group(function () {
        Route::get('/dashboard/employees', 'index');
        Route::get('/dashboard/employees/add-employee', 'create');
        Route::post('/dashboard/employees/add-employee', 'store');
        Route::get('/dashboard/employees/{id}', 'show');
        Route::get('/dashboard/employees/edit/{id}', 'edit');
        Route::post('/dashboard/employees/edit/{id}', 'update');
        Route::post('/dashboard/employees/remove', 'destroy');
        Route::post('/dashboard/employees/remove/{id}', 'destroy');
    });

    Route::controller(SettingController::class)->group(function () {
        Route::get('/dashboard/settings', 'index');
        Route::get('/dashboard/settings/add-setting', 'create');
        Route::post('/dashboard/settings/add-setting', 'store');
        Route::get('/dashboard/settings/{id}', 'show');
        Route::get('/dashboard/settings/edit/{id}', 'edit');
        Route::post('/dashboard/settings/edit/{id}', 'update');
        Route::post('/dashboard/settings/remove/{id}', 'destroy');
    });

    Route::controller(LogController::class)->group(function () {
        Route::get('/dashboard/logs', 'index');
        Route::get('/dashboard/logs/{id}', 'show');

    });
});


Route::view('profile', 'profile')
    ->middleware(['auth'])
    ->name('profile');

require __DIR__ . '/auth.php';
