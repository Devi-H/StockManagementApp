import {faker} from '@faker-js/faker';

describe('supplier page test', () => {
    before(() => {
        cy.login('admin')
        cy.on('uncaught:exception', (err, runnable) => {
            // returning false here prevents Cypress from
            // failing the test
            return false
        })
        let name= faker.company.name()
        cy.visit(`/dashboard/suppliers`)
        cy.url().should('include', `/dashboard/suppliers`)
        cy.get("button").contains("Add Supplier").click()
        cy.get("div#crud-modal input[name='supplierName']").type(name)
        cy.get("div#crud-modal input[name='email']").type(faker.internet.email())
        cy.get("div#crud-modal input[name='phoneNumber']").type(faker.phone.number())
        cy.get("div#crud-modal input[name='zipcode']").type(faker.location.zipCode())
        cy.get("div#crud-modal input[name='city']").type(faker.location.city())
        cy.get("div#crud-modal input[name='country']").type(faker.location.country())


        cy.get("div#crud-modal input[name='street']").type(faker.location.street())
        cy.get("div#crud-modal input[name='houseNumber']").type(faker.number.int({min: 0, max: 1000}))
        cy.get("button[type='submit']").contains('Add new supplier').click()
        cy.contains(`supplier ${name} created`)
        //cy.logout()
    })

    it('should be able to see an list of suppliers', () => {
       cy.get("form li").should('have.length.greaterThan', 0)
    });

});
