import { faker } from '@faker-js/faker';


describe('testing edit product', () => {
before(()=>{
    cy.createCategoryAndParent()
    cy.createProduct()

})
    beforeEach(()=>{
       cy.login('admin')
        cy.visit('/dashboard/products').then(() => {
            cy.get("table tr a:first").contains('Edit').click()
        })
    })

    it('check input types',()=>{
        cy.get("input[name='productName']").invoke('val', faker.commerce.productName())
            .invoke('val')
            .should(value => {
                expect(typeof value === 'string', 'input should be an string').to.eq(true) // passes
            })

        cy.get("input[name='description']").invoke('val', faker.commerce.productDescription())
            .invoke('val')
            .should(value => {
                expect(typeof value === 'string', 'input should be an string').to.eq(true) // passes
            })

        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()

        cy.get("input[name='selectedCategory']").invoke('val').should('not.be.empty')
            .should(value =>{
                expect(Number.isInteger(parseInt(value)), 'input should be an integer').to.eq(true) // passes
            })

        cy.get("input[name='brandName']").invoke('val', faker.company.name())
            .invoke('val')
            .should(value => {
                expect(typeof value === 'string', 'input should be an string').to.eq(true) // passes
            })

        cy.get("input[name='location']").invoke('val', faker.commerce.department())
            .invoke('val')
            .should(value => {
                expect(typeof value === 'string', 'input should be an string').to.eq(true) // passes
            })

        cy.get("input[name='barcode']").invoke('val', faker.commerce.isbn({ separator: '' }))
            .invoke('val')
            .should(value => {
                console.log(value)
                expect(Number.isInteger(parseInt(value)), 'input should be an integer').to.eq(true) // passes
            })

        cy.get("input[name='stockQuantity']").invoke('val', faker.number.int({ min: 1, max: 1000 }))
            .invoke('val')
            .should(value => {
                expect(Number.isInteger(parseInt(value)), 'input should be an integer').to.eq(true) // passes
            })

        cy.get("input[name='regularPrice']").invoke('val', faker.commerce.price({ min: 100, max: 200 }))
            .invoke('val')
            .should(value => {
                expect(Number.isInteger(parseInt(value)), 'input should be an integer').to.eq(true) // passes
            })

        cy.get("input[name='salePrice']").invoke('val', faker.commerce.price({ min: 1, max: 100 }))
            .invoke('val')
            .should(value => {
                expect(Number.isInteger(parseInt(value)), 'input should be an integer').to.eq(true) // passes
            })
    });

    it('should not update product if productName empty', () => {
        cy.url().should('include','/dashboard/products/edit')

        cy.get("input[name='productName']").invoke('val', '').then(()=>{

            cy.get("#editProductUploadImageAndButtonsContainer button[id='submitBtn']:first").click()

            cy.get("input[name='productName']").should('be.focused').type(faker.commerce.productName())
        })
    });

    it('should not update product if description empty', ()=>{
        cy.get("input[name='productName']").invoke('val', faker.commerce.productName())
        cy.get("input[name='description']").invoke('val', '')
        cy.get("#editProductUploadImageAndButtonsContainer button[id='submitBtn']").click()

        cy.get("input[name='description']").should('be.focused')
        cy.get("input[name='description']").type(faker.commerce.productDescription())
    });
    it('should not update product if category empty', ()=>{
        cy.get("input[name='productName']").invoke('val', faker.commerce.productName())
        cy.get("input[name='description']").invoke('val', faker.commerce.productDescription())
        cy.get("input[name='brandName']").invoke('val', faker.company.name())
        cy.get("input[name='location']").invoke('val', faker.commerce.department())
        cy.get("input[name='barcode']").invoke('val', faker.commerce.isbn({ separator: '' }))
        cy.get("input[name='stockQuantity']").invoke('val', faker.number.int({ min: 1, max: 1000 }))
        cy.get("input[name='regularPrice']").invoke('val', faker.commerce.price({ min: 100, max: 200 }))
        cy.get("input[name='salePrice']").invoke('val', faker.commerce.price({ min: 1, max: 100 }))

        cy.get("input[name='selectedCategory']").invoke('val','')

        cy.get("#editProductUploadImageAndButtonsContainer button[id='submitBtn']").click()
        cy.contains('category field is required')

        cy.get("#my-error-modal button").click()
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='selectedCategory']").invoke('val').should('not.be.empty')
    });
    it('should not update product if brandName empty', ()=>{
        cy.get("input[name='productName']").invoke('val', faker.commerce.productName())
        cy.get("input[name='description']").invoke('val', faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").invoke('val', '')

        cy.get("#editProductUploadImageAndButtonsContainer button[id='submitBtn']").click()

        cy.get("input[name='brandName']").should('be.focused')
        cy.get("input[name='brandName']").type(faker.company.name())
    });
    it('should not update product if location empty', ()=>{
        cy.get("input[name='productName']").invoke('val', faker.commerce.productName())
        cy.get("input[name='description']").invoke('val', faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").invoke('val', faker.company.name())
        cy.get("input[name='location']").invoke('val', '')
        cy.get("#editProductUploadImageAndButtonsContainer button[id='submitBtn']").click()

        cy.get("input[name='location']").should('be.focused')
        cy.get("input[name='location']").type(faker.commerce.department())
    });
    it('should not update product if barcode empty', ()=>{
        cy.get("input[name='productName']").invoke('val', faker.commerce.productName())
        cy.get("input[name='description']").invoke('val', faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").invoke('val', faker.company.name())
        cy.get("input[name='location']").invoke('val', faker.commerce.department())
        cy.get("input[name='barcode']").invoke('val', '')

        cy.get("#editProductUploadImageAndButtonsContainer button[id='submitBtn']").click()

        cy.get("input[name='barcode']").should('be.focused')
        cy.get("input[name='barcode']").type(faker.commerce.isbn({ separator: '' }))

    });
    it('should not update product if stockQuantity empty', ()=>{
        cy.get("input[name='productName']").invoke('val', faker.commerce.productName())
        cy.get("input[name='description']").invoke('val', faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").invoke('val', faker.company.name())
        cy.get("input[name='location']").invoke('val', faker.commerce.department())
        cy.get("input[name='barcode']").invoke('val', faker.commerce.isbn({ separator: '' }))
        cy.get("input[name='stockQuantity']").invoke('val', '')

        cy.get("#editProductUploadImageAndButtonsContainer button[id='submitBtn']").click()

        cy.get("input[name='stockQuantity']").should('be.focused')
        cy.get("input[name='stockQuantity']").type(faker.number.int({ min: 1, max: 1000 }))
    });
    it('should not update product if regularPrice empty', ()=>{
        cy.get("input[name='productName']").invoke('val', faker.commerce.productName())
        cy.get("input[name='description']").invoke('val', faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").invoke('val', faker.company.name())
        cy.get("input[name='location']").invoke('val', faker.commerce.department())
        cy.get("input[name='barcode']").invoke('val', faker.commerce.isbn({ separator: '' }))
        cy.get("input[name='stockQuantity']").invoke('val', faker.number.int({ min: 1, max: 1000 }))
        cy.get("input[name='regularPrice']").invoke('val', '')

        cy.get("#editProductUploadImageAndButtonsContainer button[id='submitBtn']").click()

        cy.get("input[name='regularPrice']").should('be.focused')
        cy.get("input[name='regularPrice']").type(faker.commerce.price({ min: 100, max: 200 }))
    });
    it('should not update product if salePrice empty', ()=>{
        cy.get("input[name='productName']").invoke('val', faker.commerce.productName())
        cy.get("input[name='description']").invoke('val', faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").invoke('val', faker.company.name())
        cy.get("input[name='location']").invoke('val', faker.commerce.department())
        cy.get("input[name='barcode']").invoke('val', faker.commerce.isbn({ separator: '' }))
        cy.get("input[name='stockQuantity']").invoke('val', faker.number.int({ min: 1, max: 1000 }))
        cy.get("input[name='regularPrice']").invoke('val', faker.commerce.price({ min: 100, max: 200 }))
        cy.get("input[name='salePrice']").invoke('val', '')

        cy.get("#editProductUploadImageAndButtonsContainer button[id='submitBtn']").click()

        cy.get("input[name='salePrice']").should('be.focused')
        cy.get("input[name='salePrice']").type(faker.commerce.price({ min: 1, max: 100 }))
    });
    it('should preview a image when the image is dropped in the image upload box', () => {
        cy.get("input[name='productName']").invoke('val', faker.commerce.productName())
        cy.get("input[name='description']").invoke('val', faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").invoke('val', faker.company.name())
        cy.get("input[name='location']").invoke('val', faker.commerce.department())
        cy.get("input[name='barcode']").invoke('val', faker.commerce.isbn({ separator: '' }))
        cy.get("input[name='stockQuantity']").invoke('val', faker.number.int({ min: 1, max: 1000 }))
        cy.get("input[name='regularPrice']").invoke('val', faker.commerce.price({ min: 100, max: 200 }))
        cy.get("input[name='salePrice']").invoke('val', faker.commerce.price({ min: 1, max: 100 }))

        cy.get('#dropzone')
            .selectFile("cypress/fixtures/test-image.jpeg", { action: 'drag-drop' });
        cy.get("#previewImage").should('not.have.attr', 'src', 'https://img.freepik.com/premium-vector/default-image-icon-vector-missing-picture-page-website-design-mobile-app-no-photo-available_87543-11093.jpg')

        cy.get("input[name='productImg']").invoke('val').should('not.be.empty')
    });

    it('should redirect to dashboard/products after updating product',()=> {
        const productName = faker.commerce.productName()
        const description = faker.commerce.productDescription()
        cy.get("input[name='productName']").invoke('val', productName)
        cy.get("input[name='description']").invoke('val', description)
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").invoke('val', faker.company.name())
        cy.get("input[name='location']").invoke('val', faker.commerce.department())
        cy.get("input[name='barcode']").invoke('val', faker.commerce.isbn({ separator: '' }))
        cy.get("input[name='stockQuantity']").invoke('val', faker.number.int({ min: 1, max: 1000 }))
        cy.get("input[name='regularPrice']").invoke('val', faker.commerce.price({ min: 100, max: 200 }))
        cy.get("input[name='salePrice']").invoke('val', faker.commerce.price({ min: 1, max: 100 }))

        cy.get('#dropzone').selectFile("cypress/fixtures/test-image.jpeg", { action: 'drag-drop' });
        cy.get("#previewImage").should('not.have.attr', 'src', 'https://img.freepik.com/premium-vector/default-image-icon-vector-missing-picture-page-website-design-mobile-app-no-photo-available_87543-11093.jpg')

        cy.get("input[name='productImg']").invoke('val').should('not.be.empty').then(()=>{
            cy.get("#editProductUploadImageAndButtonsContainer button[id='submitBtn']").click()

            cy.url().should('not.include','/add-product')
            cy.contains(productName)
            cy.contains(description)
        })
    });

    it('should have updated data',()=> {
        let oldData = {
            "productName" : cy.get("input[name='productName']"),
            "description" : cy.get("input[name='description']"),
            "brandName" : cy.get("input[name='brandName']"),
            "location" : cy.get("input[name='location']"),
            "barcode" : cy.get("input[name='barcode']"),
            "stockQuantity" : cy.get("input[name='stockQuantity']"),
            "regularPrice" : cy.get("input[name='regularPrice']"),
            "salePrice" : cy.get("input[name='salePrice']"),
        }
        const newData = {
            "productName" : faker.commerce.productName(),
            "description" : faker.commerce.productDescription(),
            "brandName" : faker.company.name(),
            "location" : faker.commerce.department(),
            "barcode" : faker.commerce.isbn({ separator: '' }),
            "stockQuantity" : faker.number.int({ min: 1, max: 1000 }),
            "regularPrice" : faker.commerce.price({ min: 100, max: 200 }),
            "salePrice" : faker.commerce.price({ min: 1, max: 100 }),
        }

        Object.entries(newData).forEach(([key, value]) => {

            cy.get('input[name="'+key+'"]').then(elem => {
                oldData[key] = Cypress.$(elem).val();
            }).invoke('val', value)

        });

        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()

        cy.get('#dropzone').selectFile("cypress/fixtures/test-image-2.jpeg", { action: 'drag-drop' });

        cy.get("#previewImage").should('not.have.attr', 'src', 'https://img.freepik.com/premium-vector/default-image-icon-vector-missing-picture-page-website-design-mobile-app-no-photo-available_87543-11093.jpg')

        cy.get("input[name='productImg']").invoke('val').should('not.be.empty').then(()=>{
            cy.get("#editProductUploadImageAndButtonsContainer button[id='submitBtn']").click()

            cy.url().should('not.include','/add-product').should('include','/dashboard/products')

            cy.get("table tr a:first").contains('Edit').click().then(()=>{
                Object.entries(oldData).forEach(([key, value]) => {
                    console.log(`${key}: ${value}`);
                    cy.get('input[name="'+key+'"]').should('include.value', newData[key])
                });

            })
        })
    });

})
