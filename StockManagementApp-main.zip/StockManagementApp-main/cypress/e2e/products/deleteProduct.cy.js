import {faker} from '@faker-js/faker';

let productId

describe('testing delete product', () => {
    before(()=>{
        //create category
        cy.createCategoryAndParent()
        //create product
        cy.createProduct()
    })

    it('should not delete product if user is employee', () => {
        cy.login('employee')

        cy.url().should('include', '/products')
        cy.log(cy.get("table tr:last"))

        cy.get("table tr:last").invoke('attr', 'id')
            .then((id) => {
                productId = id
            })

        cy.request({
            url: `/dashboard/products/remove/${productId}`,
            failOnStatusCode: false,
            followRedirect: true
        }).then((resp) => {
            // redirect status code is 301
            expect(resp.status).to.eq(403)
        })
    })


    it("should show een confirm popup, asking if the admin is sure about deleting the product and delete product",() => {
        cy.login('admin')
        cy.visit('dashboard/products')
        cy.url().should('include', 'dashboard/products')
        cy.get("table tr:last").invoke('attr', 'id')
            .then((id) => {
                productId = id

                cy.visit(`/dashboard/products/edit/${productId}`)
                cy.url().should('include',`/dashboard/products/edit/${productId}`)
                cy.get("button").contains("Delete product").click()

                cy.on('window:confirm', (text) => {
                    expect(text).to.eq('Are you sure you want to delete this product?');
                });

                cy.url().should("not.include", '/dashboard/products/edit')
                cy.get(`#${productId}`).should('not.exist')
            })
    })
})
