import {faker} from '@faker-js/faker';



describe('testing products as Employee', () => {

    beforeEach(()=>{
        cy.login('employee')
        cy.url().should('include','/products')
    })

  it('go to products page', ()=> {
    cy.visit('/products')

    cy.url().should('include','/products')
    cy.contains('Product name')
  });

    it('should not be able to access the add product page',()=> {
        cy.login('employee')

        cy.request({
            url: `/dashboard/products/add-product`,
            failOnStatusCode: false,
            followRedirect: true
        }).then((resp) => {
            expect(resp.status).to.equal(403)
        })

    });
})
