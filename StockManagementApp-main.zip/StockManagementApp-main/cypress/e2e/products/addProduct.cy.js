import { faker } from '@faker-js/faker';

describe('testing add product', () => {

    before(()=>{
        //create category
        cy.createCategoryAndParent()

        cy.login('admin')
        cy.visit('/dashboard/products/add-product')
    })
    beforeEach(()=>{
        cy.login("admin")
        cy.url().should('include','/dashboard')
        cy.visit('/dashboard/products/add-product')
    })

    it('check input types',()=>{
        cy.get("input[name='productName']").type(faker.commerce.productName())
            .invoke('val')
            .should(value => {
                expect(typeof value === 'string', 'input should be an string').to.eq(true) // passes
            })

        cy.get("input[name='description']").type(faker.commerce.productDescription())
            .invoke('val')
            .should(value => {
                expect(typeof value === 'string', 'input should be an string').to.eq(true) // passes
            })

        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()

        cy.get("input[name='selectedCategory']").invoke('val').should('not.be.empty')
            .should(value =>{
                expect(Number.isInteger(parseInt(value)), 'input should be an integer').to.eq(true) // passes
            })

        cy.get("input[name='brandName']").type(faker.company.name())
            .invoke('val')
            .should(value => {
                expect(typeof value === 'string', 'input should be an string').to.eq(true) // passes
            })

        cy.get("input[name='location']").type(faker.commerce.department())
            .invoke('val')
            .should(value => {
                expect(typeof value === 'string', 'input should be an string').to.eq(true) // passes
            })

        cy.get("input[name='barcode']").type(faker.commerce.isbn({ separator: '' }))
            .invoke('val')
            .should(value => {
                console.log(value)
                expect(Number.isInteger(parseInt(value)), 'input should be an integer').to.eq(true) // passes
            })

        cy.get("input[name='stockQuantity']").type(faker.number.int({ min: 1, max: 1000 }))
            .invoke('val')
            .should(value => {
                expect(Number.isInteger(parseInt(value)), 'input should be an integer').to.eq(true) // passes
            })

        cy.get("input[name='regularPrice']").type(faker.commerce.price({ min: 100, max: 200 }))
            .invoke('val')
            .should(value => {
                expect(Number.isInteger(parseInt(value)), 'input should be an integer').to.eq(true) // passes
            })

        cy.get("input[name='salePrice']").type(faker.commerce.price({ min: 1, max: 100 }))
            .invoke('val')
            .should(value => {
                expect(Number.isInteger(parseInt(value)), 'input should be an integer').to.eq(true) // passes
            })
    });

    it('should not create product if productName empty', () => {
        cy.url().should('include','/dashboard/products/add-product').then(
            () =>{
                cy.get("button[id='addProductButton']").click()
                cy.get("input[name='productName']").should('be.focused')
                cy.get("input[name='productName']").type(faker.commerce.productName())
            }
        )
    });
    it('should not create product if description empty', ()=>{
        cy.get("input[name='productName']").type(faker.commerce.productName())
        cy.get("button[id='addProductButton']").click()
        cy.get("input[name='description']").should('be.focused')
        cy.get("input[name='description']").type(faker.commerce.productDescription())
    });
    it('should not create product if category empty', ()=>{
        cy.get("input[name='productName']").type(faker.commerce.productName())
        cy.get("input[name='description']").type(faker.commerce.productDescription())
        cy.get("input[name='brandName']").type(faker.company.name())
        cy.get("input[name='location']").type(faker.commerce.department())
        cy.get("input[name='barcode']").type(faker.commerce.isbn({ separator: '' }))
        cy.get("input[name='stockQuantity']").type(faker.number.int({ min: 1, max: 1000 }))
        cy.get("input[name='regularPrice']").type(faker.commerce.price({ min: 100, max: 200 }))
        cy.get("input[name='salePrice']").type(faker.commerce.price({ min: 1, max: 100 }))

        cy.get("button[id='addProductButton']").click()
        cy.contains('category field is required')

        cy.get("#my-error-modal button").click()
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='selectedCategory']").invoke('val').should('not.be.empty')
    });
    it('should not create product if brandName empty', ()=>{
        cy.get("input[name='productName']").type(faker.commerce.productName())
        cy.get("input[name='description']").type(faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()

        cy.get("button[id='addProductButton']").click()

        cy.get("input[name='brandName']").should('be.focused')
        cy.get("input[name='brandName']").type(faker.company.name())
    });
    it('should not create product if location empty', ()=>{
        cy.get("input[name='productName']").type(faker.commerce.productName())
        cy.get("input[name='description']").type(faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").type(faker.company.name())

        cy.get("button[id='addProductButton']").click()

        cy.get("input[name='location']").should('be.focused')
        cy.get("input[name='location']").type(faker.commerce.department())
    });
    it('should not create product if barcode empty', ()=>{
        cy.get("input[name='productName']").type(faker.commerce.productName())
        cy.get("input[name='description']").type(faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").type(faker.company.name())
        cy.get("input[name='location']").type(faker.commerce.department())

        cy.get("button[id='addProductButton']").click()

        cy.get("input[name='barcode']").should('be.focused')
        cy.get("input[name='barcode']").type(faker.commerce.isbn({ separator: '' }))

    });
    it('should not create product if stockQuantity empty', ()=>{
        cy.get("input[name='productName']").type(faker.commerce.productName())
        cy.get("input[name='description']").type(faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").type(faker.company.name())
        cy.get("input[name='location']").type(faker.commerce.department())
        cy.get("input[name='barcode']").type(faker.commerce.isbn({ separator: '' }))

        cy.get("button[id='addProductButton']").click()

        cy.get("input[name='stockQuantity']").should('be.focused')
        cy.get("input[name='stockQuantity']").type(faker.number.int({ min: 1, max: 1000 }))
    });
    it('should not create product if regularPrice empty', ()=>{
        cy.get("input[name='productName']").type(faker.commerce.productName())
        cy.get("input[name='description']").type(faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").type(faker.company.name())
        cy.get("input[name='location']").type(faker.commerce.department())
        cy.get("input[name='barcode']").type(faker.commerce.isbn({ separator: '' }))
        cy.get("input[name='stockQuantity']").type(faker.number.int({ min: 1, max: 1000 }))

        cy.get("button[id='addProductButton']").click()

        cy.get("input[name='regularPrice']").should('be.focused')
        cy.get("input[name='regularPrice']").type(faker.commerce.price({ min: 100, max: 200 }))
    });
    it('should not create product if salePrice empty', ()=>{
        cy.get("input[name='productName']").type(faker.commerce.productName())
        cy.get("input[name='description']").type(faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").type(faker.company.name())
        cy.get("input[name='location']").type(faker.commerce.department())
        cy.get("input[name='barcode']").type(faker.commerce.isbn({ separator: '' }))
        cy.get("input[name='stockQuantity']").type(faker.number.int({ min: 1, max: 1000 }))
        cy.get("input[name='regularPrice']").type(faker.commerce.price({ min: 100, max: 200 }))

        cy.get("button[id='addProductButton']").click()

        cy.get("input[name='salePrice']").should('be.focused')
        cy.get("input[name='salePrice']").type(faker.commerce.price({ min: 1, max: 100 }))
    });
    it('should preview a image when the image is dropped in the image upload box', () => {
        cy.get("input[name='productName']").type(faker.commerce.productName())
        cy.get("input[name='description']").type(faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").type(faker.company.name())
        cy.get("input[name='location']").type(faker.commerce.department())
        cy.get("input[name='barcode']").type(faker.commerce.isbn({ separator: '' }))
        cy.get("input[name='stockQuantity']").type(faker.number.int({ min: 1, max: 1000 }))
        cy.get("input[name='regularPrice']").type(faker.commerce.price({ min: 100, max: 200 }))
        cy.get("input[name='salePrice']").type(faker.commerce.price({ min: 1, max: 100 }))

        cy.get('#dropzone')
            .selectFile("cypress/fixtures/test-image.jpeg", { action: 'drag-drop' });
        cy.get("#previewImage").should('not.have.attr', 'src', 'https://img.freepik.com/premium-vector/default-image-icon-vector-missing-picture-page-website-design-mobile-app-no-photo-available_87543-11093.jpg')

        cy.get("input[name='productImg']").invoke('val').should('not.be.empty')
    });

    it('should redirect to dashboard/products after adding a new product',()=> {
        const productName = faker.commerce.productName()
        const description = faker.commerce.productDescription()
        cy.get("input[name='productName']").type(productName)
        cy.get("input[name='description']").type(description)
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").type(faker.company.name())
        cy.get("input[name='location']").type(faker.commerce.department())
        cy.get("input[name='barcode']").type(faker.commerce.isbn({ separator: '' }))
        cy.get("input[name='stockQuantity']").type(faker.number.int({ min: 1, max: 1000 }))
        cy.get("input[name='regularPrice']").type(faker.commerce.price({ min: 100, max: 200 }))
        cy.get("input[name='salePrice']").type(faker.commerce.price({ min: 1, max: 100 }))

        cy.get('#dropzone').selectFile("cypress/fixtures/test-image.jpeg", { action: 'drag-drop' });
        cy.get("#previewImage").should('not.have.attr', 'src', 'https://img.freepik.com/premium-vector/default-image-icon-vector-missing-picture-page-website-design-mobile-app-no-photo-available_87543-11093.jpg')

        cy.get("input[name='productImg']").invoke('val').should('not.be.empty').then(()=>{
            cy.get("button[id='addProductButton']").click()

            cy.url().should('not.include','/add-product')
            cy.contains(productName)
            cy.contains(description)
        })
    });

})
