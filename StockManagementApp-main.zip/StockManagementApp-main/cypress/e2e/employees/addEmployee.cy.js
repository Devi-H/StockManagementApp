import {faker} from '@faker-js/faker';

describe('testing add employee', () => {
    beforeEach(() => {
        cy.login('admin')
        cy.visit('/dashboard/employees/add-employee')
        cy.url().should('include','/dashboard/employees/add-employee')

    })

    it('should not create a employee if name input is empty',()=>{
        cy.get("input[name='lastname']").type(faker.person.lastName())
        cy.get("input[name='email']").type(faker.internet.email())
        cy.get("input[name='password']").type(faker.internet.password())
        cy.get("button").contains('Save').click()
        cy.get("div#my-error-modal").should("include.text","The name field is required")
    })

    it('should not create a employee if lastname input is empty',()=>{
        cy.get("input[name='name']").type(faker.person.firstName())
        cy.get("input[name='email']").type(faker.internet.email())
        cy.get("input[name='password']").type(faker.internet.password())
        cy.get("button").contains('Save').click()
        cy.get("div#my-error-modal").should("include.text","The lastname field is required")
    })

    it('should not create a employee if email input is empty',()=>{
        cy.get("input[name='name']").type(faker.person.firstName())
        cy.get("input[name='lastname']").type(faker.person.lastName())
        cy.get("input[name='password']").type(faker.internet.password())
        cy.get("button").contains('Save').click()
        cy.get("div#my-error-modal").should("include.text","The email field is required")
    })
    it('should not create a employee if password input is empty',()=>{
        cy.get("input[name='name']").type(faker.person.firstName())
        cy.get("input[name='lastname']").type(faker.person.lastName())
        cy.get("input[name='email']").type(faker.internet.email())
        cy.get("button").contains('Save').click()
        cy.get("div#my-error-modal").should("include.text","The password field is required")
    })

    it('should create a new employee',()=>{
        let firstname = faker.person.firstName()
        cy.get("input[name='name']").type(firstname)
        cy.get("input[name='lastname']").type(faker.person.lastName())
        cy.get("input[name='email']").type(faker.internet.email())
        cy.get("input[name='password']").type('!7Df'+faker.internet.password({ length: 20 }))
        cy.get("button").contains('Save').click()
        cy.location().should(loc => {
            expect(loc.pathname).to.equal('/dashboard/employees')
        })
        cy.get("form#removeEmployee").contains(firstname).should("exist")
    })

})
