import {faker} from '@faker-js/faker';
const words = faker.lorem.words()
let categoryId
describe('testing edit category', () => {

    before(() => {
        cy.createCategory(words)
    })
    /*
    it('should make an category', () => {
        cy.login('admin')
        cy.visit('/dashboard/categories')
        cy.url().should('include', '/dashboard/categories')
        cy.get("form li").should('have.length.greaterThan', 0)
        cy.get("button").contains('Add Category').click()
        cy.get("input[name='categoryName']").type(words)
        cy.get("button[type='submit']").contains('Add new category').click()
        //table has multiple pages, so it should be checked on the last page
        cy.get("form li div label").contains(words).should('exist')
    })*/

    it('should edit a existing category', () => {
        cy.login('admin')
        cy.visit('/dashboard/categories')
        cy.url().should('include', '/dashboard/categories')
        cy.get("form#removeCategory ul li").should('have.length.greaterThan', 1)
        cy.findCategory(words)
        cy.get("form#removeCategory li div").contains(words).parent().contains('Edit').click()

        cy.get("input[name='categoryName']").clear().type('Laptops')
        cy.get("button[type='submit']").contains('Apply changes ').click()

        cy.get("form#removeCategory li div label").contains(words).should('not.exist')
        cy.get("form#removeCategory li div label").contains('Laptops').should('exist')

        cy.get("form#removeCategory ul li:last").find('input').invoke('attr', 'value')
            .then((id) => {
                categoryId = id
            })
    })

    it('should not be able to edit the category if the user is not admin', () => {
        cy.login('employee')

        // Verify the URL is as expected
        cy.request({
            url: `/dashboard/categories/edit/${categoryId}`,
            failOnStatusCode: false,
            followRedirect: true
        }).then((resp) => {
            // redirect status code is 301
            expect(resp.status).to.eq(403)
        })
    })
})



