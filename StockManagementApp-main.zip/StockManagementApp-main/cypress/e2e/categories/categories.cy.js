describe('Show al categories', () => {
    before(()=>{
        cy.createCategory('Computers')
        cy.createCategory()
    })
    beforeEach(()=>{
        // Navigate to the login page
        cy.login('admin')
        // Navigate to the categories page
        cy.visit('/dashboard/categories')
    })

    it('should show al categories', () => {
        // Assert that the categories are displayed
        cy.get("form li").should('have.length.greaterThan', 1)
    });

    it('should be able to search an category', () => {
        // Assert that the URL includes '/dashboard/categories'
        cy.url().should('include', '/dashboard/categories')

        // Type the category name in the search input field
        cy.get("input[id='simple-search']").type("Computers")

        // Assert that the category name is displayed
        cy.get("form#removeCategory li div label").contains('Computers').should('exist')
        cy.get("form#removeCategory ul").find("li").its("length").should('eq', 1)

    });

});
