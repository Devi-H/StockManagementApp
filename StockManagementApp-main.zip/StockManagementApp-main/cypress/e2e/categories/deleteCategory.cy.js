import {faker} from '@faker-js/faker';
let words = faker.commerce.department()
let fakeCategory = faker.commerce.department()
describe('testing delete category', () => {

    beforeEach(()=>{
        cy.login('admin')
        cy.visit('/dashboard/categories')

        cy.get("form#removeCategory ul").find("li").its("length").then(($length)=>{
            cy.log($length)
            if ($length < 2){
                cy.createCategory(words)
                cy.createCategory(fakeCategory)
            }else{
                cy.get(`form#removeCategory ul li:first div:first label`).invoke('text').then((text) => {
                    cy.log(text)
                    words = text
                })
                cy.get("form#removeCategory ul li:last div:first label").invoke('text').then((text) => {
                    cy.log(text)
                    fakeCategory = text
                })
            }
        })
        cy.log(words)
    })
/*
    it('should add an category', () => {
        cy.login('admin')
        cy.visit('/dashboard/categories')
        cy.url().should('include', '/dashboard/categories')
        cy.get("form#removeCategory li").should('have.length.greaterThan', 0)
        cy.get("button").contains('Add Category').click()
        cy.get("input[name='categoryName']").type(words)
        cy.get("button[type='submit']").contains('Add new category').click()
        cy.get("form#removeCategory li").should('have.length.greaterThan', 1)
    });*/

    it('should delete a category', () => {
        cy.login('admin')
        cy.visit('/dashboard/categories')
        cy.url().should('include', '/dashboard/categories')
        cy.get("form#removeCategory li").should('have.length.greaterThan', 0)
        cy.get("form#removeCategory li div label").contains(words).click()
        cy.get('button[onclick="ConfirmDelete()"]').click();
        cy.on('window:confirm', () => true);
        cy.get("form#removeCategory li div label").contains(words).should('not.exist')
    })

    /*it('should add multiple categories', () => {
        cy.login('admin')
        cy.visit('/dashboard/categories')
        cy.url().should('include', '/dashboard/categories')
        cy.get("form#removeCategory li").should('have.length.greaterThan', 0)
        cy.get("button").contains('Add Category').click()
        cy.get("input[name='categoryName']").type(words)
        cy.get("button[type='submit']").contains('Add new category').click()
        cy.get("form#removeCategory li").should('have.length.greaterThan', 1)
        cy.get("button").contains('Add Category').click()
        cy.get("input[name='categoryName']").type(fakeCategory)
        cy.get("button[type='submit']").contains('Add new category').click()
        cy.get("form#removeCategory li").should('have.length.greaterThan', 2)
    })*/

    it('should delete multiple categories', () => {
        cy.login('admin')
        cy.visit('/dashboard/categories')
        cy.url().should('include', '/dashboard/categories')
        cy.get("form#removeCategory li").should('have.length.greaterThan', 0)
        cy.get("form#removeCategory li div label").contains(words).click()
        cy.get("form#removeCategory li div label").contains(fakeCategory).click()
        cy.get('button[onclick="ConfirmDelete()"]').click();
        cy.on('window:confirm', () => true);
        cy.get(`form#removeCategory li#parent-${fakeCategory}`).should('not.exist')
        cy.get(`form#removeCategory li#parent-${words}`).should('not.exist')

    })

    it('should not be able to delete a category if the user is not admin', () => {
        // Log in as an employee
        cy.login('employee');

        // Visit the categories dashboard and handle 403 status code
        cy.visit('/dashboard/categories', { failOnStatusCode: false });

        // Verify the URL is as expected
        cy.url().should('include', '/dashboard/categories');
    });

})
