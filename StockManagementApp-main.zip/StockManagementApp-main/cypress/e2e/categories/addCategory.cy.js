import {faker} from '@faker-js/faker';

describe('testing add category', () => {
    before(() => {
        cy.createCategoryAndParent()
    })
    it('should not be able to add category if the user is not admin', () => {
        cy.login('employee')

        cy.request({
            url: `/dashboard/categories/add-category`,
            method: 'POST',
            data: {
                "categoryName": "test category"
            },
            failOnStatusCode: false,
            followRedirect: true
        }).then((resp) => {
            expect(resp.status).to.not.be.within(200,299)
        })
    })

    it("should open add category modal", () => {
        cy.login('admin')
        cy.visit(`/dashboard/categories`)
        cy.url().should('include', `/dashboard/categories`)
        cy.get("button").contains("Add Category").click()
    })

    it("should not add category if categoryName empty", () => {
        cy.openAddCategoryModal()
        cy.get("button[type='submit']").contains("Add new category").click()
        cy.get("input[name='categoryName']").should('be.focused')
    })
    it("should add category without parent", () => {
        const category = faker.commerce.department()
        cy.openAddCategoryModal()
        cy.get("input[name='categoryName']").type(category)
        cy.get("button[type='submit']").contains("Add new category").click()

        cy.get("form#removeCategory").should('contain.text', category)
    })

    it("should add category with parent category", () => {
        cy.openAddCategoryModal()
        const category = faker.commerce.department()
        let parentCategory
        cy.get("#dropdown1 ul li:first label span:first").then($el => {
            parentCategory = $el.text()
        }).then(() => {
            cy.get("input[name='categoryName']").type(category)
            cy.get("button#dropdownDefaultButton").click()
            cy.get("#dropdown1 ul li:first").click()

            cy.get("button[type='submit']").contains("Add new category").click()

            cy.get("form#removeCategory ul li").contains(parentCategory).should('exist')
            cy.get("form#removeCategory ul li").contains(parentCategory).parent().parent().should('contain.html', "ul")
                .and('contain', category)

        })
    })

    it("should add category with 2 parent category", () => {
        cy.openAddCategoryModal()
        const category = faker.commerce.department()
        let parentCategory = []
        cy.get("#dropdown1 ul li:first label span:first").then($el => {
            parentCategory[0] = $el.text()
        }).then(() => {
            cy.get("#dropdown1 ul li:last-child label span:first").then($el2 => {
                parentCategory[1] = $el2.text()
            }).then(() => {
                cy.log(parentCategory)
                cy.get("input[name='categoryName']").type(category)
                cy.get("button#dropdownDefaultButton").click()
                cy.get("#dropdown1 ul li:first").click()
                cy.get("#dropdown1 ul li:last-child").click()

                cy.get("button[type='submit']").contains("Add new category").click()

                cy.get(`form#removeCategory ul li#parent-${parentCategory[0]}`).contains(parentCategory[0]).should('exist')
                cy.get(`form#removeCategory ul li#parent-${parentCategory[0]}`).contains(parentCategory[0]).parent().parent().should('contain.html', "ul")
                    .and('contain', category)

                cy.get(`form#removeCategory ul li#parent-${parentCategory[1]}`).contains(parentCategory[1]).should('exist')
                cy.get(`form#removeCategory ul li#parent-${parentCategory[1]}`).contains(parentCategory[1]).parent().parent().should('contain.html', "ul")
                    .and('contain', category)

            })
        })
    })

})
