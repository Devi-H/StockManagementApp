describe('login page', () => {
  //input data
const email = "admin@admin.com"
const password = "Wachtwoord"

beforeEach(()=>{
  cy.visit('/login')
})


it('redirects to login page',()=>{
  cy.visit('/login')
  cy.url().should('contains','/login')

})

  it('should not login without entering the email', ()=>{
    cy.get('button[type="submit"]').click()
    cy.get("input[name='email']").should('be.focused')
    cy.get("input[name='email']").type(email)
  });
  
  it('should not login without entering the password', ()=>{
    cy.get("input[name='email']").type(email)

    cy.get("button[type='submit']").click()
    cy.get("input[name='password']").should('be.focused')
    cy.get("input[name='password']").type(password)
  });
  
  it('should not let you login without valid credentials',()=>{
    cy.get("input[name='email']").type(email)
    cy.get("input[name='password']").type(password+"wrongPassword")
    cy.get("button[type='submit']").click()

    cy.contains("These credentials do not match our records.")
  })

  it('should let the admin login ',()=>{
    cy.get("input[name='email']").type(email)
    cy.get("input[name='password']").type(password)

    cy.get("button[type='submit']").click()

    cy.contains("You're logged in!")

    cy.url().should('include','/dashboard')

  })
  it('should let the employee login ',()=>{
    cy.get("input[name='email']").type("employee@test-employee.com")
    cy.get("input[name='password']").type(password)

    cy.get("button[type='submit']").click()

    cy.contains("Test Employee")

    cy.url().should('include','/products')

  })
})
