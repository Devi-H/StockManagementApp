// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
import {faker} from "@faker-js/faker";

const users = {
    "admin": {
        "email": "admin@admin.com",
        "password": "Wachtwoord",
        "homeUrl": "/dashboard"
    },
    "employee": {
        "email": "employee@test-employee.com",
        "password": "Wachtwoord",
        "homeUrl": "/products"
    }
}
let productId
Cypress.Commands.add('login', (user = "admin") => {
    cy.clearCookies({log: true})
    cy.visit('/login')
    cy.get("input[name='email']").type(users[user].email)
    cy.get("input[name='password']").type(users[user].password)

    cy.get("button[type='submit']").click()

    cy.url().should('include', users[user].homeUrl)

})
Cypress.Commands.add('logout', (user = "Admin") => {
    //logout
    cy.get("button").contains(user).click()
    cy.get("button a").contains("Log Out").click()
    cy.url().should('include', '/')

})

Cypress.Commands.add('createCategory', (category = faker.commerce.department()) => {
    cy.login('admin')
    cy.visit(`/dashboard/categories`)
    cy.get("button").contains("Add Category").click()

    cy.get("input[name='categoryName']").type(category)
    cy.get("button[type='submit']").contains("Add new category").click()

    cy.logout()
})

Cypress.Commands.add('createCategoryAndParent', () => {
    const category = faker.commerce.department()
    cy.login('admin')
    cy.visit(`/dashboard/categories`)
    cy.get("button").contains("Add Category").click()

    cy.get("input[name='categoryName']").type(category)
    cy.get("button[type='submit']").contains("Add new category").click()

    cy.get("button").contains("Add Category").click()

    const newCategory = faker.commerce.department()
    let parentCategory
    cy.get("#dropdown1 ul li:first label span:first").then($el => {
        parentCategory = $el.text()
    }).then(() => {
        cy.get("input[name='categoryName']").type(newCategory)
        cy.get("button#dropdownDefaultButton").click()
        cy.get("#dropdown1 ul li:first").click()

        cy.get("button[type='submit']").contains("Add new category").click()
        cy.logout()
    })
})

Cypress.Commands.add('openAddCategoryModal', () => {
    cy.login('admin')
    cy.visit(`/dashboard/categories`)
    cy.url().should('include', `/dashboard/categories`)
    cy.get("button").contains("Add Category").click()
})

Cypress.Commands.add('findCategory', (category) => {
    cy.get("input[id='simple-search']").type(category)
})

Cypress.Commands.add('createProduct', () => {
    cy.login('admin')
    cy.visit("/dashboard/products/add-product").then(() => {
        cy.get("input[name='productName']").type(faker.commerce.productName())
        cy.get("input[name='description']").type(faker.commerce.productDescription())
        cy.get("button[id='dropdown-button']").click()
        cy.get("#dropdown-menu a:first").click()
        cy.get("input[name='brandName']").type(faker.company.name())
        cy.get("input[name='location']").type(faker.commerce.department())
        cy.get("input[name='barcode']").type(faker.commerce.isbn({separator: ''}))
        cy.get("input[name='stockQuantity']").type(faker.number.int({min: 1, max: 1000}))
        cy.get("input[name='regularPrice']").type(faker.commerce.price({min: 100, max: 200}))
        cy.get("input[name='salePrice']").type(faker.commerce.price({min: 1, max: 100}))

        cy.get('#dropzone').selectFile("cypress/fixtures/test-image.jpeg", {action: 'drag-drop'});
        cy.get("#previewImage").should('not.have.attr', 'src', 'https://img.freepik.com/premium-vector/default-image-icon-vector-missing-picture-page-website-design-mobile-app-no-photo-available_87543-11093.jpg')

        cy.get("input[name='productImg']").invoke('val').should('not.be.empty').then(() => {
            cy.get("button[id='addProductButton']").click()
        })
        cy.url().should('include', 'dashboard/products')
        cy.get("table tr:last").invoke('attr', 'id')
            .then((id) => {
                productId = id
            })
        cy.logout()
    })
})

Cypress.Commands.add('createSupplier', (name = faker.company.name()) => {
    cy.login('admin').then(()=>{
        cy.visit("dashboard/suppliers").then(()=>{
            cy.url().should('include', '/dashboard/suppliers')
            cy.get("button").contains("Add Supplier").click()
            cy.get("input[name='supplierName']").type(name)
            cy.get("input[name='email']").type(faker.internet.email())
            cy.get("input[name='phoneNumber']").type(faker.phone.number())
            cy.get("input[name='country']").type(faker.location.country())
            cy.get("input[name='city']").type(faker.location.city())
            cy.get("input[name='zipcode']").type(faker.location.zipCode())
            cy.get("input[name='street']").type(faker.location.street())
            cy.get("input[name='houseNumber']").type(faker.number.int({min: 0, max: 1000}))

            cy.get("button[type='submit']").contains('Add new supplier').click()
            cy.contains(`supplier ${name} created`)
            cy.logout()
        })
    })
})
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
