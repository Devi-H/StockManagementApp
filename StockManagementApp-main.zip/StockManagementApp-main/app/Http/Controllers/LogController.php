<?php

namespace App\Http\Controllers;

use App\Models\Log;
use Illuminate\Http\Request;
use Illuminate\Routing\Controllers\Middleware;
use Spatie\Permission\Middleware\PermissionMiddleware;

class LogController extends Controller
{
    public static function middleware(): array
    {
        return [
            new Middleware(PermissionMiddleware::using(['show-log']),
                only: ['index', 'show'])
        ];
    }
    public function index()
    {
        $logs = Log::paginate(10);
//        dd($logs);
        return view('adminPanel.all-logs-list', compact('logs'));
    }

    public function show(string $id)
    {
        $logs = Log::find($id);
        return view('adminPanel.a-log-list', compact('logs'));
    }
}
