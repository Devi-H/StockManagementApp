<?php
//usercontroller.php
namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Middleware\PermissionMiddleware;

class UserController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware(PermissionMiddleware::using(['view-employee|create-employee|edit-employee|delete-employee']),
                only: ['index', 'show']),
            new Middleware(PermissionMiddleware::using(['create-employee']),
                only: ['create', 'store']),
            new Middleware(PermissionMiddleware::using(['edit-employee']),
                only: ['edit', 'update']),
            new Middleware(PermissionMiddleware::using(['delete-employee']),
                only: ['destroy'])
        ];
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $employees = User::role('Employee')->get();
        return view('adminPanel/employees',['employees'=> $employees]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('adminPanel/employees/create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
//        dd($request->post('password'));
        //
        //validate data (input fields and if user exists)
        $request->validate( [
            'name' => 'required|string',
            'lastname' => 'required|string',
            'email' => 'required|unique:users|email',
            'password' => 'required|min:6|regex:/^.*(?=.{3,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[\d\x])(?=.*[!$#%]).*$/',
        ], [
            'password.regex' => 'Password should meet requirements - A uppercase letter, A lowercase letter, A number and A symbol',
        ]);

        //save data
        $fullname = $request->post('name').' '.$request->post('lastname');
        $newUser = new User();
        $newUser->name =$fullname;
        $newUser->email = $request->post('email');
        $newUser->password = Hash::make($request->post('password'));
        $newUser->save();
        $newUser->assignRole('Employee');

        //redirect back to employee overview
        return redirect("dashboard/employees");

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $user = User::find($id)->where('id', $id)->first();
        $splitName = explode(' ', $user->name);
        $firstName = $splitName[0];
        $lastName = str_replace($firstName.' ', '',$user->name);
        $email = $user->email;
//        dump($firstName);
//        dump($lastName);
//        dump($email);
//        dump('password');
        $user->firstName = $firstName;
        $user->lastName = $lastName;
        $user->email = $email;
        $user->password = ('password');
        return view('adminPanel/employees/edit',compact('user'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)

    {
        try {
            $user = User::find($id)->where('id', $id)->first();

            $user->update([
                "name" => $request->post('name')." ".$request->post('lastname'),
                "email" => $request->post('email'),
            ]);

            if ($request->post('password') != '') {
                $user->update([
                    "password" => Hash::make($request->post('password'))
                ]);
            }
            return redirect("dashboard/employees")->with('success', 'Data of '.$user->name.' is successfully updated');
        } catch(\Exception $exception){
            return redirect("dashboard/employees")->with('error', $exception->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request,string $id = "")
    {
        try {
            $userIds = array_filter($request->post(), function($key) {
                return $key != '_token';
            }, ARRAY_FILTER_USE_KEY);

            User::destroy($userIds);

            return redirect("dashboard/employees")->with('success', 'Employee(s) deleted');
        }catch (\Exception $exception){
            return redirect("dashboard/employees")->with('error', $exception->getCode());
        }
    }
}
