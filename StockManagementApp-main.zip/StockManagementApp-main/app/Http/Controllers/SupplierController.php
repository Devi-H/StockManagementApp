<?php

namespace App\Http\Controllers;

use App\Livewire\AdminPanel\Suppliers;
use App\Models\Category;
use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;
use Spatie\Permission\Middleware\PermissionMiddleware;

class SupplierController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware(PermissionMiddleware::using(['view-supplier|create-supplier|edit-supplier|delete-supplier']),
                only: ['index', 'show']),
            new Middleware(PermissionMiddleware::using(['create-supplier']),
                only: ['create', 'store']),
            new Middleware(PermissionMiddleware::using(['edit-supplier']),
                only: ['edit', 'update']),
            new Middleware(PermissionMiddleware::using(['delete-supplier']),
                only: ['destroy'])
        ];
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $suppliers = Supplier::paginate(10);
        $categories = Category::all();
        return view("adminPanel/suppliers/index", compact('suppliers', 'categories'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //

    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        if (!Supplier::where('name', $request->post('supplierName'))->exists()) {
            $supplier = new Supplier;
            $supplier->name = $request->post('supplierName');
            $supplier->email = $request->post('email');
            $supplier->phoneNumber = $request->post('phoneNumber');
            $supplier->country = $request->post('country');
            $supplier->city = $request->post('city');
            $supplier->zipcode = $request->post('zipcode');
            $supplier->street = $request->post('street');
            $supplier->houseNumber = $request->post('houseNumber');
            if ($request->post('houseNumberAddition')) {
                $supplier->houseNumberAddition = $request->post('houseNumberAddition');
            }

            $supplier->save();

            $categoryIds = [];
            $productIds = [];
            $orderIds = [];

            if (count($request->post()) > 2) {
                foreach ($request->post() as $key => $value) {
                    if (str_contains($key, 'category')) {
                        $categoryIds[] = str_replace('category-', '', $key);
                    }
                    if (str_contains($key, 'product')) {
                        $productIds[] = str_replace('product-', '', $key);
                    }
                    if (str_contains($key, 'order')) {
                        $orderIds[] = str_replace('order-', '', $key);
                    }
                }
                if ($categoryIds) {
                    $supplier->categories()->attach($categoryIds);
                }
                if ($productIds) {
                    $supplier->products()->attach($productIds);
                }
                if ($orderIds) {
                    $supplier->orders()->attach($orderIds);
                }
            }
        }
        return redirect("/dashboard/suppliers")->with('success', "supplier " . $supplier->name . " created");
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $supplier = Supplier::find($id)->where('id', $id)->first();
        return view("adminPanel/suppliers/edit", compact('supplier'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {


            $supplier = Supplier::find($id)->where('id', $id)->first();

            //detach relationships
            $supplier->categories()->detach();
            $supplier->products()->detach();

//                $supplier->orders()->attach($orderIds);


            $supplier->name = $request->post('supplierName');
            $supplier->email = $request->post('email');
            $supplier->phoneNumber = $request->post('phoneNumber');
            $supplier->country = $request->post('country');
            $supplier->city = $request->post('city');
            $supplier->zipcode = $request->post('zipcode');
            $supplier->street = $request->post('street');
            $supplier->houseNumber = $request->post('houseNumber');
            $supplier->houseNumberAddition = $request->post('houseNumberAddition');

            $supplier->update();

            $categoryIds = [];
            $productIds = [];
            $orderIds = [];

            if (count($request->post()) > 2) {
                foreach ($request->post() as $key => $value) {
                    if (str_contains($key, 'category')) {
                        $categoryIds[] = str_replace('category-', '', $key);
                    }
                    if (str_contains($key, 'product')) {
                        $productIds[] = str_replace('product-', '', $key);
                    }
                    if (str_contains($key, 'order')) {
                        $orderIds[] = str_replace('order-', '', $key);
                    }
                }
                if ($categoryIds) {
                    $supplier->categories()->attach($categoryIds);
                }
                if ($productIds) {
                    $supplier->products()->attach($productIds);
                }
                if ($orderIds) {
                    $supplier->orders()->attach($orderIds);
                }
            }

            return redirect("/dashboard/suppliers")->with('success', "supplier " . $supplier->name . " updated");

        } catch (\Exception $exception) {
            return redirect("/dashboard/suppliers")->with('error', $exception->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request, string $id = "")
    {
        try {
            $supplierIds = array_filter($request->post(), function ($key) {
                return $key != '_token';
            }, ARRAY_FILTER_USE_KEY);

            Supplier::destroy($supplierIds);

            return redirect("dashboard/suppliers")->with('success', 'Supplier(s) deleted');
        } catch (\Exception $exception) {
            return redirect("dashboard/suppliers")->with('error', $exception->getCode());
        }
    }
}
