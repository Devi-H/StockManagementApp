<?php

namespace App\Http\Controllers;

use App\Models\Log;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Spatie\Permission\Middleware\PermissionMiddleware;
class ProductController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware(PermissionMiddleware::using(['view-product|create-product|edit-product|delete-product']),
                only: ['index', 'show']),
            new Middleware(PermissionMiddleware::using(['create-product']),
                only: ['create', 'store']),
            new Middleware(PermissionMiddleware::using(['edit-product']),
                only: ['edit', 'update']),
            new Middleware(PermissionMiddleware::using(['edit-product-as-employee']),
                only: ['editAsEmployee', 'updateAsEmployee']),
            new Middleware(PermissionMiddleware::using(['delete-product']),
                only: ['destroy'])
        ];
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $products = Product::All();
        $categories = Category::All();

        if (Auth::user()->hasRole('Admin')) {
            return view("adminPanel/products", compact('products', 'categories'));
        } elseif (Auth::user()->hasRole('Employee')) {
            return view("products/index", compact('products', 'categories'));
        } else {
            return response(view('errors.403'), 403);
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        $categories = Category::All()->reverse();
        return view("adminPanel/addProducts", compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $valid = $request->validate([
            "productName" => "required|string",
            "description" => "required|string",
            "selectedCategory" => "required|string",
            "brandName" => "required|string",
            "location" => "required|string",
            "barcode" => "required|integer",
            "stockQuantity" => "required|integer",
            "regularPrice" => "required",
            "salePrice" => "required",
            "productImg" => "required"
        ]);


        $product = new Product();
        $product->productName = $request->post("productName");
        $product->description = $request->post("description");
        $product->categoryId = $request->post("selectedCategory");
        $product->brandName = $request->post("brandName");
        $product->location = $request->post("location");
        $product->barcode = $request->post("barcode");
        $product->stockQuantity = $request->post("stockQuantity");
        $product->regularPrice = $request->post("regularPrice");
        $product->salePrice = $request->post("salePrice");

        $product->picture = basename($request->post("productImg"));
        $product->save();
        Storage::move('livewire-tmp/' . $product->picture, 'public/photos/' . $product->picture);

        return redirect('/dashboard/products');

    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $categories = Category::All()->reverse();
        $product = Product::find($id);
        return view('adminPanel/editProduct', compact('categories', 'product'));

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
        /*     $valid = $request->validate([
                 "productName" => "required|string",
                 "description" => "required|string",
                 "selectedCategory" => "required|string",
                 "brandName" => "required|string",
                 "location" => "required|string",
                 "barcode" => "required|integer",
                 "stockQuantity" => "required|integer",
                 "regularPrice" => "required",
                 "salePrice" => "required",
                 "productImg" => "required|mimes:jpeg,jpg,png"
             ]);*/

        $valid = $request->validate([
            "productName" => "required|string",
            "description" => "required|string",
            "selectedCategory" => "required|string",
            "brandName" => "required|string",
            "location" => "required|string",
            "barcode" => "required|integer",
            "stockQuantity" => "required|integer",
            "regularPrice" => "required",
            "salePrice" => "required",
            //"productImg" => "required"
        ]);

        $product = Product::find($id);

        if ($product->picture != 'https://img.freepik.com/premium-vector/default-image-icon-vector-missing-picture-page-website-design-mobile-app-no-photo-available_87543-11093.jpg') {
            $imagePath = '/photos/' . $product->picture;


            if (Storage::disk('public')->exists($imagePath) && basename($request->post("productImg"))) {
                Storage::disk('public')->delete($imagePath);
            }
        }

        // save $request into the Product with $id

        $product->productName = $request->post("productName");
        $product->description = $request->post("description");
        $product->categoryId = $request->post("selectedCategory");
        $product->brandName = $request->post("brandName");
        $product->location = $request->post("location");
        $product->barcode = $request->post("barcode");
        $product->stockQuantity = $request->post("stockQuantity");
        $product->regularPrice = $request->post("regularPrice");
        $product->salePrice = $request->post("salePrice");

        //check if product image already exists in the storage
        if (basename($request->post("productImg")) != $product->picture && basename($request->post("productImg"))) {
            $product->picture = basename($request->post("productImg"));
        }

        $product->save();

        if (basename($request->post("productImg"))) {
            Storage::move('livewire-tmp/' . $product->picture, 'public/photos/' . $product->picture);
        }

        return redirect('/dashboard/products');
    }

    public function editAsEmployee(string $id){
        $product = Product::find($id);
        return view('products.edit', compact('product'));
    }
    public function updateAsEmployee(Request $request, string $id){

        $request->validate([
            "location" => "required|string",
            "stockQuantity" => "required|integer"
        ]);

        $product = Product::find($id);
        $oldData = [
            "oldLocation" => $product->location,
            "oldStockQuantity" => $product->stockQuantity
        ];
        $product->location = $request->post("location");
        $product->stockQuantity = $request->post("stockQuantity");
        $product->save();

        //todo: code for logging employees made changes here:
        $log = new Log();
        $log->oldLocation = $oldData["oldLocation"];
        $log->oldStockQuantity = $oldData["oldStockQuantity"];
        $log->newLocation = $product->location;
        $log->newStockQuantity = $product->stockQuantity;
        $log->employee_Id = Auth::id();
        $log->product_Id = $product->id;
        $log->save();


        return redirect('/products')->with('success', 'Product updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $product = Product::find($id);

        if ($product) {
            $product->delete();
            return redirect('/dashboard/products')->with('success', 'Product deleted successfully');
        } else {
            return redirect('/dashboard/products')->with('error', 'Product not found');
        }
    }
}
