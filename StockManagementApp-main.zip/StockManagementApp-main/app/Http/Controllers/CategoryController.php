<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;
use Spatie\Permission\Middleware\PermissionMiddleware;

class CategoryController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware(PermissionMiddleware::using(['view-category|create-category|edit-category|delete-category']),
                only: ['index', 'show']),
            new Middleware(PermissionMiddleware::using(['create-category']),
                only: ['create', 'store']),
            new Middleware(PermissionMiddleware::using(['edit-category']),
                only: ['edit', 'update']),
            new Middleware(PermissionMiddleware::using(['delete-category']),
                only: ['destroy'])
        ];
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // receive categories from category model.
        $categories = Category::paginate(10);
        return view("adminPanel/categories/index", compact('categories'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //

    }

    /**
     * Store a newly created category in the database.
     */
    public function store(Request $request)
    {
        if (!Category::where('name', $request->post('categoryName'))->exists()) {
            $category = new Category;
            $category->name = $request->post('categoryName');

            $category->save();
            if (count($request->post()) > 2) {
                echo "it's bigger than 2, the category has parents" . count($request->post());
                $onlyCategoriesIds = [];

                //filter data to get only the checkboxes data
                $onlyCategories = array_filter($request->post(), function ($input) {
                    return $input == "on";
                });

                //loop through the checkboxes data and push it into a new array.
                foreach ($onlyCategories as $key => $value) {
                    $onlyCategoriesIds[] = str_replace('parentCategory-', '', $key);
                }

                $category->parentCategories()->attach($onlyCategoriesIds);
            }

        }
        return redirect('/dashboard/categories');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $category = Category::find($id)->where('id', $id)->first();
        $categories = Category::all();
        return view("adminPanel/categories/edit", compact("category", "categories"));

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        if (Category::where('id', $id)->exists()) {
            $category = Category::find($id);
            $category->parentCategories()->detach();

            Category::where('id', $id)->update([
                "name" => $request->post('categoryName')
            ]);

            if (count($request->post()) > 2) {
                echo "it's bigger than 2, the category has parents" . count($request->post());
                $onlyCategoriesIds = [];

                //filter data to get only the checkboxes data
                $onlyCategories = array_filter($request->post(), function ($input) {
                    return $input == "on";
                });

                //loop through the checkboxes data and push it into a new array.
                foreach ($onlyCategories as $key => $value) {
                    $onlyCategoriesIds[] = str_replace('parentCategory-', '', $key);
                }
                $category->parentCategories()->attach($onlyCategoriesIds);
            }
        }
        return redirect('dashboard/categories');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request,string $id = "")
    {
        foreach (array_keys($request->post()) as $key){
            //if key is a child category
//            todo: delete child instead of detach when child has no other parents.
            if(str_contains($key, "child")){
                $json = json_decode($request->post($key));
                Category::find($json->parent)->children()->detach($json->child);
//                if (Category::find())

            }
            //if key is a parent category
            if(str_contains($key,"category")){
                Category::find($request->post($key))->children()->detach($request->post($key));
                    Category::find($request->post($key))->delete($request->post($key));
            }
        }

        return redirect('/dashboard/categories');
    }

}
