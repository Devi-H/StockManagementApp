<?php

namespace App\Livewire\AdminPanel;

use App\Models\User;
use Livewire\Component;
use Livewire\WithPagination;

class Employees extends Component
{
    use WithPagination;

    public string $searchEmployee = "";

    public function render()
    {
        $employees = User::search("name",$this->searchEmployee)->role('Employee')->paginate(10);

        return view('livewire.admin-panel.employees', ['employees' => $employees, 'searchEmployee' => $this->searchEmployee]);
    }
    public function updating($key): void
    {
        if ($key === 'searchEmployee') {
            $this->resetPage();
        }
    }
}
