<?php

namespace App\Livewire\AdminPanel;

use App\Models\Category;
use App\Models\Product;
use App\Models\Supplier;
use Livewire\Component;
use Livewire\WithPagination;

class Suppliers extends Component
{
    use WithPagination;

    public string $searchSupplier = "";
    public string $searchCategory = "";

    public function render()
    {
        $suppliers = Supplier::search("name",$this->searchSupplier)->paginate(10);
        $categories = Category::search("name",$this->searchCategory)->paginate(10);

        return view('livewire.admin-panel.suppliers', [
            'suppliers' => $suppliers,
            'searchSupplier' => $this->searchSupplier,
            'categories' => $categories,
            'searchCategory' => $this->searchCategory
        ]);
    }
    public function updating($key): void
    {
        if ($key === 'searchSupplier') {
            $this->resetPage();
        }
    }
}
