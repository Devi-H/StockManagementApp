<?php

namespace App\Livewire\AdminPanel\Components;

use App\Models\Category;
use App\Models\Product;
use App\Models\Supplier;
use Livewire\Component;

class ModalWithCheckboxes extends Component
{
    private string $model;
    public string $type;
    public string $searchTerm = "";
    public Supplier $supplier;

    public function render()
    {
        $data = null;
        switch ($this->model){
            case "Product":
                $data = Product::search('productName',$this->searchTerm)->paginate(10);
                $this->type = "products";
                break;
            case "Category":
                $data = Category::search('name',$this->searchTerm)->paginate(10);
                $this->type = "categories";
                break;
            default: return null;
        }

        return view('livewire.admin-panel.components.modal-with-checkboxes',[
            "data" => $data,
            "searchTerm" => $this->searchTerm,
            "type" => $this->type
        ]);
    }

    public function mount(string $model,Supplier  $supplier)
    {
        $this->model = $model;
        $this->supplier = $supplier;
    }

}
