<?php

namespace App\Livewire\AdminPanel\Components;

use Livewire\Component;

class ModalToShowList extends Component
{
    public string $type;
    public $model;
    public $data;
    public $id;
    public function render()
    {

        return view('livewire.admin-panel.components.modal-to-show-list',[
            'data' => $this->data,
            'type' => $this->type,
            'id' => $this->id,
        ]);
    }
    public function mount($type,$data,$id)
    {
        $this->type = $type;
        $this->data = $data;
        $this->id = $id;
    }
}
