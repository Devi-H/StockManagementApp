<?php

namespace App\Livewire;

use App\Models\Product;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;

class AddProducts extends Component
{
    use WithFileUploads;

    public $files = [];
    public $picture;
    public $url; // Declare a public property
    public Product $product;
    public $pictureInputValue;
    public function render()
    {

        return view('livewire.add-products');
    }

    public function updatedFiles()
    {

        foreach ($this->files as $file) {
            $this->url = $file->temporaryUrl();
            $this->pictureInputValue = $file->getFilename(); // Get the URL of the file
        }
    }

    public function mount($product = null)
    {
        if ($product != null){
            $this->product = $product;
            if ($this->product) {
                $imagePath = 'photos/' . $this->product->picture;
                if (Storage::disk('public')->exists($imagePath)) {
                    $this->url = Storage::disk('public')->url($imagePath);
                }else {
                    $this->url = 'https://img.freepik.com/premium-vector/default-image-icon-vector-missing-picture-page-website-design-mobile-app-no-photo-available_87543-11093.jpg';
                }
            }
        }
        else {
            $this->url = 'https://img.freepik.com/premium-vector/default-image-icon-vector-missing-picture-page-website-design-mobile-app-no-photo-available_87543-11093.jpg';
        }
    }
}
