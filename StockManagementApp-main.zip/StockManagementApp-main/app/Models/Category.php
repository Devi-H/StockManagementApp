<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    protected $id = 'id';
    protected $primaryKey = 'id';
    protected $name = 'string';

    const created_at = 'creation_date';
    const updated_at = 'updated_date';

    /**
     * Get the attributes that should be cast.
     *
//     * @return array<string, string>
     */
  /*  protected function casts(): array
    {
        return [
            'parentCategories' => 'array'
        ];
    }*/

    public function parentCategories(){
        return $this->belongsToMany(Category::Class,'categoryParent_categoryChild','category_id','parent_id')->withPivot('id');
    }
    public function children(){
        return $this->belongsToMany(Category::Class,'categoryParent_categoryChild','parent_id','category_id')->withPivot('id');
    }
}
