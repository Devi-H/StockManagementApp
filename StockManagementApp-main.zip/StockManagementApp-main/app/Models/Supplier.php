<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Supplier extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = [
        'name',
        'email',
        'phoneNumber',
        'country',
        'city',
        'zipcode',
        'street',
        'houseNumber',
        'houseNumberAddition'
    ];


    public function categories(){
        return $this->belongsToMany(Category::Class,'supplier_category_relation','supplier_id','category_id')->withPivot('id');
    }
    public function products(){
        return $this->belongsToMany(Product::Class,'supplier_product_relation','supplier_id','product_id')->withPivot('id');
    }
    public function orders(){
        return $this->belongsToMany(Order::Class,'supplier_order_relation','supplier_id','order_id')->withPivot('id');
    }
}
