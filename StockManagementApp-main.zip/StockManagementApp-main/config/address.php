<?php

return [
    'driver' => 'here',

    'here' => [
        'token' => env('HERE_TOKEN'),
    ],

    'locales' => null, // By default app.locale
];
