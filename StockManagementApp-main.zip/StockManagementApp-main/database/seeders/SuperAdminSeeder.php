<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class SuperAdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $superAdmin = User::create([
            'name' => 'Super Admin',
            'email' => 'super-admin@admin.com',
            'password' => Hash::make('Wachtwoord')
        ]);
        $superAdmin->assignRole('Super Admin');

        // Creating Admin User
        $admin = User::create([
            'name' => 'Admin',
            'email' => 'admin@admin.com',
            'password' => Hash::make('Wachtwoord')
        ]);
        $admin->assignRole('Admin');

        // Creating Test Employee User
        $employee = User::create([
            'name' => 'Test Employee',
            'email' => 'employee@test-employee.com',
            'password' => Hash::make('Wachtwoord')
        ]);
        $employee->assignRole('Employee');

        // Creating Test Customer User
        $customer = User::create([
            'name' => 'Test Customer',
            'email' => 'customer@test-customer.com',
            'password' => Hash::make('Wachtwoord')
        ]);
        $customer->assignRole('Costumer');
    }
}
