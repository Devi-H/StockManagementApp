<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $permissions = [
            'view-employee',
            'create-employee',
            'edit-employee',
            'delete-employee',
            'view-category',
            'create-category',
            'edit-category',
            'delete-category',
            'view-product',
            'create-product',
            'edit-product',
            'edit-product-as-employee',
            'delete-product',
            'view-supplier',
            'create-supplier',
            'edit-supplier',
            'delete-supplier',
            'view-order',
            'create-order',
            'edit-order',
            'delete-order',
            'view-favorite',
            'save-favorite',
            'edit-favorite',
            'remove-favorite',
            'show-log'
        ];

        // Looping and Inserting Array's Permissions into Permission Table
        foreach ($permissions as $permission) {
            Permission::create(['name' => $permission]);
        }
    }
}
