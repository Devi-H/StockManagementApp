<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Role::create(['name' => 'Super Admin']);
        $admin = Role::create(['name' => 'Admin']);
        $employee = Role::create(['name' => 'Employee']);
        $costumer = Role::create(['name' => 'Costumer']);

        $admin->givePermissionTo([
            'view-employee',
            'create-employee',
            'edit-employee',
            'delete-employee',

            'view-category',
            'create-category',
            'edit-category',
            'delete-category',

            'view-product',
            'create-product',
            'edit-product',
            'delete-product',

            'view-supplier',
            'create-supplier',
            'edit-supplier',
            'delete-supplier',

            'view-order',
            'create-order',
            'edit-order',
            'delete-order',

            'show-log'
        ]);

        $employee->givePermissionTo([
            'view-product',
            'edit-product-as-employee'
        ]);

        $costumer->givePermissionTo([
            'view-product',
            'view-favorite',
            'save-favorite',
            'edit-favorite',
            'remove-favorite'
        ]);
    }
}
