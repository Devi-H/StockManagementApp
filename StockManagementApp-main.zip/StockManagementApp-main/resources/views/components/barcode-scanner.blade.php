<style>
    canvas.drawingBuffer {
        display: none;
    }
</style>
<div>
    <div id="default-modal" tabindex="-1" aria-hidden="true"
         class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
        <div class="relative p-4 w-full max-w-2xl max-h-full">
            <!-- Modal content -->
            <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                <!-- Modal header -->
                <div class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                    <button id="hideModal" type="button"
                            class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                            data-modal-hide="default-modal">
                        <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                             viewBox="0 0 14 14">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>
                <!-- Modal body -->
                <div class="p-4 md:p-5 space-y-4">
                    <video id="camera" type="LiveStream">
                    </video>
                    <div id="red-stripe"></div>

                </div>
                <div class="modal-footer" style="display:none"></div>
            </div>
        </div>
    </div>


    <style>

        #red-stripe {
            position: absolute;
            top: 50%;
            left: 20px;
            width: 600px;
            height: 2px;
            background: red;
        }
    </style>
    <script type="text/javascript" src="https://unpkg.com/@zxing/library@latest/umd/index.min.js"></script>
    <script>

        // Constants
        const BARCODE_LENGTH = 13;
        const BARCODE_FORMATS = [
            ZXing.BarcodeFormat.EAN_8,
            ZXing.BarcodeFormat.EAN_13,
            ZXing.BarcodeFormat.CODE_39,
        ];

        // Helper functions
        function validateBarcode(barcode) {
            if (!barcode) {
                throw new Error('Barcode is empty');
            }

            if (barcode.length !== BARCODE_LENGTH) {
                throw new Error('Invalid barcode length');
            }

            if (!/^\d+$/.test(barcode)) {
                throw new Error('Barcode contains non-digit characters');
            }

            return true;
        }

        function handleBarcodeScan(result) {
            if (!result) {
                return null;
            }

            let resultText = result.text;

            if (resultText.length < BARCODE_LENGTH) {
                resultText = resultText.padStart(BARCODE_LENGTH, '0');
            }

            validateBarcode(resultText);

            return resultText;
        }

        // Main code
        const codeReader = new ZXing.BrowserMultiFormatReader(null, BARCODE_FORMATS);
        let barcodeInput = document.getElementById('barcode');

        document.getElementById('barcodeScannerBtn').addEventListener('click', function () {
            codeReader.decodeFromVideoDevice(null, 'camera', (result, err) => {
                try {
                    const barcode = handleBarcodeScan(result);

                    if (barcode !== null) {
                        barcodeInput.value = barcode;

                        const event = new Event('input', {
                            bubbles: true,
                            cancelable: true,
                        });
                        barcodeInput.dispatchEvent(event);

                        codeReader.reset();

                        document.querySelector('[data-modal-hide="default-modal"]').click();
                    }
                } catch (error) {
                    console.error(error);
                }

                if (err && !(err instanceof ZXing.NotFoundException)) {
                    console.error(err);
                }
            });
        });

        //stop when close button has been clicked
        document.getElementById('hideModal').addEventListener('click', function () {
            codeReader.reset();
        });

    </script>
</div>
