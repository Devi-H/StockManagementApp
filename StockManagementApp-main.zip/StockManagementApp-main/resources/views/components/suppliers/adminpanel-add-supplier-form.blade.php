<div>
    <!-- Main modal -->
    <div id="crud-modal" tabindex="-1" aria-hidden="true"
         class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center
         w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
        <div class="relative p-4 w-full max-w-md max-h-full min-w-full">
            <!-- Modal content -->
            <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                <!-- Modal header -->
                <div class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        Create New Supplier
                    </h3>
                    <button type="button"
                            class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg
                            text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600
                            dark:hover:text-white"
                            data-modal-toggle="crud-modal">
                        <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                             viewBox="0 0 14 14">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>
                <!-- Modal body -->
                <form class="p-4 md:p-5" method="post" action="{{url('dashboard/suppliers/add-supplier')}}">
                    @csrf
                    <div class="grid gap-4 mb-4 grid-cols-1 sm:grid-cols-3">
                        <div class="col-span-1">
                            <label for="name"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Name</label>
                            <input type="text" name="supplierName" id="name"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier name..." required>
                        </div>
                        <div class="col-span-1">
                            <label for="email"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Email</label>
                            <input type="email" name="email" id="email"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier email..." required>
                        </div>
                        <div class="col-span-1 mb-10">
                            <label for="phoneNumber"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Phone
                                Number</label>
                            <input type="tel" name="phoneNumber" id="phoneNumber"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier phone number..." required>
                        </div>


                        <div class="col-span-1">
                            <label for="country"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Country</label>
                            <input type="text" name="country" id="country"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier country..." required>
                        </div>
                        <div class="col-span-1">
                            <label for="city"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">City</label>
                            <input type="text" name="city" id="city"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier city..." required>
                        </div>
                        <div class="col-span-1">
                            <label for="zipcode"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Zipcode</label>
                            <input type="text" name="zipcode" id="zipcode"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier zipcode..." required>
                        </div>
                        <div class="col-span-1">
                            <label for="street"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Street</label>
                            <input type="text" name="street" id="street"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier street..." required>
                        </div>
                        <div class="col-span-1">
                            <label for="houseNumber"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">House
                                Number</label>
                            <input type="number" name="houseNumber" id="houseNumber"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier House Number..." required>
                        </div>
                        <div class="col-span-1">
                            <label for="houseNumberAddition"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">House Number
                                Addition</label>
                            <input type="text" name="houseNumberAddition" id="houseNumberAddition"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier House Number Addition...">
                        </div>


                        <div class="col-span-1">
                            <label for="category" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Category</label>
                            <livewire:admin-panel.components.modal-with-checkboxes model="Category"></livewire:admin-panel.components.modal-with-checkboxes>
                        </div>

                        {{--Show product list--}}
                        <div class="col-span-1">
                            <label for="product" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Products</label>
                            <livewire:admin-panel.components.modal-with-checkboxes model="Product"></livewire:admin-panel.components.modal-with-checkboxes>
                        </div>


                    </div>
                    <div class="flex justify-end">
                        <button type="submit"
                                class="text-white inline-flex items-center bg-blue-700 hover:bg-blue-800 focus:ring-4
                                focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5
                                text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                            <svg class="me-1 -ms-1 w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                      d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0
                                       011-1z"
                                      clip-rule="evenodd"></path>
                            </svg>
                            Add new supplier
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{--    <form class="form" method="post" action="/">--}}
    {{--        @csrf--}}
    <button data-modal-target="crud-modal" data-modal-toggle="crud-modal"
            class="block text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none
                focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600
                dark:hover:bg-blue-700 dark:focus:ring-blue-800"
            type="button">
        Add Supplier
    </button>
    {{--    </form>--}}
</div>

<script>
    let input = document.getElementById('zipcode');
    let countryInput = document.getElementById('country');
    let cityInput = document.getElementById('city');

    input.addEventListener('input', function () {
        fetch(`https://api.opencagedata.com/geocode/v1/json?q=${input.value}&key=e0a60a23377b45398b772559f4c5173c`)
            .then(response => response.json())
            .then(data => {
                if (data.results && data.results.length > 0 && data.results[0].components) {
                    let components = data.results[0].components;
                    countryInput.value = components.country || '';
                    cityInput.value = components.city || '';
                }
            });
    });
</script>
