<div>
        @foreach($logs as $log)
            {{$log->oldLocation}}
            {{$log->newLocation}}
        @endforeach

</div>
