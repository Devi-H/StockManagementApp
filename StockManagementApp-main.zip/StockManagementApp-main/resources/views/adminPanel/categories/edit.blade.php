<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                {{--<livewire:admin-panel.categories.edit :categories="$categories"></livewire:admin-panel.categories.edit>--}}

                <form class="p-4 md:p-5" method="post" action="">
                    @csrf
                    <div class="grid grid-cols-2 gap-1 content-center">
                        <div class="col-span-1 content-center">
                            <label for="name"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white content-center">Name</label>
                            <input type="text" name="categoryName" id="name"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Category name..." required="" value="{{$category->name}}">
                        </div>
                        <div class="col-span-1">
                            <label for="category" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Category</label>
                            <button id="dropdownDefaultButton"
                                    data-dropdown-toggle="dropdown1"
                                    class="w-44 justify-center text-white bg-blue-700 hover:bg-blue-800 focus:ring-4
                                    focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5
                                    text-center inline-flex items-center dark:bg-blue-600 dark:hover:bg-blue-700
                                    dark:focus:ring-blue-800"
                                    type="button">
                                Parent Categories
                                <svg class="w-2.5 h-2.5 ms-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                     fill="none" viewBox="0 0 10 6">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                          stroke-width="2" d="m1 1 4 4 4-4"/>
                                </svg>
                            </button>


                            <div id="dropdown1"
                                 class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
                                {{--                                todo: add searchbar--}}
                                <ul class="py-2 text-sm text-gray-700 dark:text-gray-200"
                                    aria-labelledby="dropdownDefaultButton">
                                    <input id="search-input"
                                           class="block w-full px-4 py-2 text-gray-800 border rounded-md  border-gray-300 focus:outline-none"
                                           type="text" placeholder="Search items" autocomplete="on">
                                    @foreach($categories as $categoryA)
                                        <li>
                                            <label
                                                class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">
                                                <input name="parentCategory-{{$categoryA->id}}" type="checkbox"
                                                       class="form-checkbox" @if($categoryA->children()->where('categories.id',$category->id)->count()) checked @endif>
                                                <span class="ml-2">{{$categoryA->name}}</span>
                                            </label>
                                        </li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                        <div class="col-span-1 mt-5 mb-1">
                            <button type="submit"
                                    class="text-white inline-flex items-center bg-blue-700 hover:bg-blue-800 focus:ring-4
                                focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5
                                text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                <svg class="me-1 -ms-1 w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                     xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd"
                                          d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0
                                       011-1z"
                                          clip-rule="evenodd"></path>
                                </svg>
                                Apply changes
                            </button>
                        </div>
                    </div>

                </form>

            </div>
        </div>
    </div>

    <script>
        const dropdownMenu = document.getElementById('dropdown1');
        const searchInput = document.getElementById('search-input');
        // Add event listener to filter items based on input
        searchInput.addEventListener('input', () => {
            const searchTerm = searchInput.value.toLowerCase();
            const items = dropdownMenu.querySelectorAll('li');

            items.forEach((item) => {
                const text = item.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    </script>
</x-app-layout>
