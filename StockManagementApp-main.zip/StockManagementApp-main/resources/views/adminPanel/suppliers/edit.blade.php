<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Suppliers') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg">
                <form class="p-4 md:p-5" method="post" action="{{url('dashboard/suppliers/edit/'.$supplier->id)}}">
                    @csrf
                    <div class="grid gap-4 mb-4 grid-cols-1 sm:grid-cols-3">
                        <div class="col-span-1">
                            <label for="name"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Name</label>
                            <input type="text" name="supplierName" id="name" value="{{$supplier->name}}"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier name..." required="">
                        </div>
                        <div class="col-span-1">
                            <label for="email"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Email</label>
                            <input type="email" name="email" id="email" value="{{$supplier->email}}"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier email..." required="">
                        </div>
                        <div class="col-span-1 mb-10">
                            <label for="phoneNumber"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Phone
                                Number</label>
                            <input type="tel" name="phoneNumber" id="phoneNumber" value="{{$supplier->phoneNumber}}"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier phone number..." required="">
                        </div>


                        <div class="col-span-1">
                            <label for="country"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Country</label>
                            <input type="text" name="country" id="country" value="{{$supplier->country}}"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier country..." required="" disabled>
                        </div>
                        <div class="col-span-1">
                            <label for="city"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">City</label>
                            <input type="text" name="city" id="city" value="{{$supplier->city}}"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier city..." required="" disabled>
                        </div>
                        <div class="col-span-1">
                            <label for="zipcode"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Zipcode</label>
                            <input type="text" name="zipcode" id="zipcode" value="{{$supplier->zipcode}}"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier zipcode..." required="">
                        </div>
                        <div class="col-span-1">
                            <label for="street"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Street</label>
                            <input type="text" name="street" id="street" value="{{$supplier->street}}"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier street..." required="">
                        </div>
                        <div class="col-span-1">
                            <label for="houseNumber"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">House
                                Number</label>
                            <input type="number" name="houseNumber" id="houseNumber" value="{{$supplier->houseNumber}}"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier House Number..." required="">
                        </div>
                        <div class="col-span-1">
                            <label for="houseNumberAddition"
                                   class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">House Number
                                Addition</label>
                            <input type="text" name="houseNumberAddition" id="houseNumberAddition"
                                   value="{{$supplier->houseNumberAddition}}"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                   focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600
                                   dark:border-gray-500 dark:placeholder-gray-400 dark:text-white
                                   dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Supplier House Number Addition...">
                        </div>


                        <div class="col-span-1">
                            <label for="category" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Category</label>
                            <livewire:admin-panel.components.modal-with-checkboxes model="Category"
                                                                                   :supplier="$supplier"></livewire:admin-panel.components.modal-with-checkboxes>
                        </div>

                        {{--Show product list--}}
                        <div class="col-span-1">
                            <label for="product" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Products</label>
                            <livewire:admin-panel.components.modal-with-checkboxes model="Product"
                                                                                   :supplier="$supplier"></livewire:admin-panel.components.modal-with-checkboxes>
                        </div>


                    </div>
                    <div class="flex justify-end">
                        <button type="submit"
                                class="text-white inline-flex items-center bg-orange-700 hover:bg-orange-800 focus:ring-4
                                focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5
                                text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                            <svg class="me-1 -ms-1 w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                      d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0
                                       011-1z"
                                      clip-rule="evenodd"></path>
                            </svg>
                            Update supplier
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</x-app-layout>
<script>
    let input = document.getElementById('zipcode');
    let countryInput = document.getElementById('country');
    let cityInput = document.getElementById('city');

    input.addEventListener('input', function () {
        fetch(`https://api.opencagedata.com/geocode/v1/json?q=${input.value}&key=e0a60a23377b45398b772559f4c5173c`)
            .then(response => response.json())
            .then(data => {
                if (data.results && data.results.length > 0 && data.results[0].components) {
                    let components = data.results[0].components;
                    countryInput.value = components.country || '';
                    cityInput.value = components.city || '';
                }
            });
    });
</script>
