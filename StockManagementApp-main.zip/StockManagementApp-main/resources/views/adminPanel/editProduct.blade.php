
<x-app-layout>

    <form method="post" action="{{url("/dashboard/products/edit/".$product->id)}}">

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>
                            {{$error}}
                        </li>
                    @endforeach
                </ul>
            </div>
        @endif
        @csrf
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div style="height: 585px;"
                         class="flex relative overflow-x-auto shadow-md sm:rounded-lg bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <div class="flex-1 w-mt-6 ml-6 ">
                            <div class="mb-2">
                                <label for="productName"
                                       class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Product
                                    Name</label>
                                <input type="text" value="{{$product->productName}}" id="productName" name="productName"
                                       class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                       required/>
                            </div>
                            <div class="mb-2">
                                <label for="description"
                                       class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Description</label>
                                <input type="text" value=" {{$product->description}}" id="description"
                                       name="description"
                                       class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                       required/>
                            </div>
                            <div class="mb-2">
                                <label for="category"
                                       class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Category</label>
                                <div class="relative group">
                                    <button type="button" id="dropdown-button"
                                            class="inline-flex justify-center w-full px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-100 focus:ring-blue-500">
                                        @if(isset($categories))
                                            @foreach($categories as $category)
                                                    @php
                                                        $productCategoryId = $product->categoryId;
                                                        $matchingCategory = $categories->where('id', $productCategoryId)->first();

                                                        $categoryName = null;
                                                    @endphp

                                                    @if($matchingCategory)
                                                        @php
                                                            $categoryName = $matchingCategory->name;

                                                        @endphp
                                                    @endif
                                                @endforeach

                                                @if($categoryName != null)
                                                        <span id="dropdown-text" class="mr-2">{{$categoryName}}</span>
                                                    @else
                                                        <span style="background-color: red" id="dropdown-text" class="mr-2"><span>&#9888;</span></span>
                                                @endif
                                        @endif
                                        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 ml-2 -mr-1"
                                             viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                            <path fill-rule="evenodd"
                                                  d="M6.293 9.293a1 1 0 011.414 0L10 11.586l2.293-2.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z"
                                                  clip-rule="evenodd"/>
                                        </svg>
                                    </button>
                                    <div id="dropdown-menu"
                                         class="hidden absolute  mt-2 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 p-1 space-y-1">

                                        @if(isset($categoryName))
                                            <input type="hidden" id="selectedCategory" name="selectedCategory"
                                                   value="{{$product->categoryId}}">
                                            @else
                                            <input style="background-color: red" type="hidden" id="selectedCategory" name="selectedCategory"
                                                   value="NULL">
                                        @endif



                                        <!-- Search input -->
                                        <input id="search-input"
                                               class="block w-full px-4 py-2 text-gray-800 border rounded-md  border-gray-300 focus:outline-none"
                                               type="text" placeholder="Search items" autocomplete="on">
                                        <!-- Dropdown content goes here -->
                                        @foreach($categories as $category)

                                            {{-- Loop through parent categories --}}
                                            @foreach($category->parentCategories as $parentCategory)
                                                <a href="#"
                                                   onclick="selectCategory('{{$parentCategory->id}}','{{$parentCategory->name}}')"
                                                   class="block px-4 py-2 text-gray-700 hover:bg-gray-100 active:bg-blue-100 cursor-pointer rounded-md">{{$parentCategory->name}}</a>
                                            @endforeach

                                            {{-- Loop through child categories --}}
                                            @foreach($category->children as $child)
                                                <a href="#"
                                                   onclick="selectCategory('{{$child->id}}','{{$child->name}}')"
                                                   class="indent-8 block px-4 py-2 text-gray-700 hover:bg-gray-100 active:bg-blue-100 cursor-pointer rounded-md">- {{$child->name}}</a>
                                            @endforeach
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                            <div class="grid gap-6 mb-2 md:grid-cols-2">
                                <div>
                                    <label for="brandName"
                                           class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Brand
                                        Name</label>
                                    <input type="text" value="{{$product->brandName}}" id="brandName" name="brandName"
                                           class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                           required/>
                                </div>
                                <div>
                                    <label for="location"
                                           class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Location</label>
                                    <input type="text" value="{{$product->location}}" id="location" name="location"
                                           class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                           required/>
                                </div>
                                <div>
                                    <label for="barcode"
                                           class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Barcode</label>

                                    <div class="flex">
                                        <input type="number" value="{{$product->barcode}}" id="barcode" name="barcode"
                                               class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                               required/>
                                        <button type="button" data-modal-target="default-modal" data-modal-toggle="default-modal" class="ml-4 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full" id="barcodeScannerBtn"><svg class="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                                                <path stroke="white" stroke-linejoin="round" stroke-width="2" d="M4 18V8a1 1 0 0 1 1-1h1.5l1.707-1.707A1 1 0 0 1 8.914 5h6.172a1 1 0 0 1 .707.293L17.5 7H19a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1Z"/>
                                                <path stroke="white" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"/>
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                                <div>
                                    <label for="stockQuantity"
                                           class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Stock
                                        Quantity</label>
                                    <input type="number" value="{{$product->stockQuantity}}" id="stockQuantity"
                                           name="stockQuantity"
                                           class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                           required/>
                                </div>
                                <div>
                                    <label for="regularPrice"
                                           class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Regular
                                        Price</label>
                                    <input type="number" step="any" value="{{$product->regularPrice}}" id="regularPrice"
                                           name="regularPrice"
                                           class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                           required/>
                                </div>
                                <div>
                                    <label for="salePrice"
                                           class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Sale
                                        Price</label>
                                    <input type="number" step="any" value="{{$product->salePrice}}" id="salePrice" name="salePrice"
                                           class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                           required/>
                                </div>
                                <!-- Delete button -->
                                <div class="mb-2">
                                    <button type="button" onclick="confirmDelete('{{url("/dashboard/products/remove/".$product->id)}}')"
                                            class="text-white bg-red-500 hover:bg-red-600 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800">
                                        Delete product
                                    </button>
                                </div>
                            </div>
                        </div>
<div id="editProductUploadImageAndButtonsContainer" class="flex-1 relative">

    <livewire:add-products :product="$product"/>

</div>

                    </div>
                </div>
            </div>
        </div>
    </form>
    <x-barcode-scanner/>
    <script>
        // JavaScript to toggle the dropdown
        const dropdownButton = document.getElementById('dropdown-button');
        const dropdownMenu = document.getElementById('dropdown-menu');
        const searchInput = document.getElementById('search-input');
        let isOpen = false; // Set to true to open the dropdown by default

        // Function to toggle the dropdown state
        function toggleDropdown() {
            isOpen = !isOpen;
            dropdownMenu.classList.toggle('hidden', !isOpen);
        }

        // Set initial state
        // toggleDropdown();

        dropdownButton.addEventListener('click', () => {
            toggleDropdown();
        });

        // Add event listener to filter items based on input
        searchInput.addEventListener('input', () => {
            const searchTerm = searchInput.value.toLowerCase();
            const items = dropdownMenu.querySelectorAll('a');

            items.forEach((item) => {
                const text = item.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });

        function selectCategory(categoryId,categoryName) {
            console.log(categoryName);
            document.getElementById('selectedCategory').value = categoryId;
            document.getElementById('dropdown-text').innerHTML = categoryName;
            toggleDropdown()
        }

        function confirmDelete(url) {
            if (confirm('Are you sure you want to delete this product?')) {
                window.location.href = url;
            }
        }
    </script>

</x-app-layout>


