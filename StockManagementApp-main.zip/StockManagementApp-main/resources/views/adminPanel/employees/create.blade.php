<x-app-layout>
    <div class="flex justify-center items-center h-screen">
        <form method="post" action="" class="w-full max-w-lg">
            @csrf

            <!-- First Name -->
            <div class="flex flex-wrap -mx-3 mb-6 w-full">
                <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                    <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-first-name">
                        First Name
                    </label>
                    <input name="name" value="{{ old('name') }}" class="appearance-none block w-full bg-gray-200 text-gray-700 border rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white @error('name') border-red-500 @enderror" id="grid-first-name" type="text" placeholder="Jane">
                    @error('name')
                    <p class="text-red-500 text-xs italic">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Last Name -->
                <div class="w-full md:w-1/2 px-3">
                    <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-last-name">
                        Last Name
                    </label>
                    <input name="lastname" value="{{ old('lastname') }}" class="appearance-none block w-full bg-gray-200 text-gray-700 border rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white @error('lastname') border-red-500 @enderror" id="grid-last-name" type="text" placeholder="Doe">
                    @error('lastname')
                    <p class="text-red-500 text-xs italic">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <!-- Email -->
            <div class="flex flex-wrap -mx-3 mb-6 w-full">
                <div class="w-full px-3">
                    <label class="block uppercase tracking-wide text-gray-600 text-xs font-bold mb-2" for="grid-mail">
                        Email
                    </label>
                    <input name="email" value="{{ old('email') }}" class="appearance-none block w-full bg-gray-200 text-gray-700 border rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white @error('email') border-red-500 @enderror" id="email" type="email" placeholder="Email Address">
                    @error('email')
                    <p class="text-red-500 text-xs italic">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <!-- Password -->
            <div class="flex flex-wrap -mx-3 mb-6 w-full">
                <div class="w-full px-3">
                    <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-password">
                        Password
                    </label>
                    <input name="password" class="appearance-none block w-full bg-gray-200 text-gray-700 border rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white @error('password') border-red-500 @enderror" id="grid-password" type="password" placeholder="Password">
                    @error('password')
                    <p class="text-red-500 text-xs italic">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <!-- Save Button -->
            <div class="w-full flex justify-center">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    Save
                </button>
            </div>

            <!-- Extracting component classes -->
            <button class="btn btn-blue"></button>

            <style>
                .btn {
                    @apply font-bold py-2 px-4 rounded;
                }
                .btn-blue {
                    @apply bg-blue-500 text-white;
                }
                .btn-blue:hover {
                    @apply bg-blue-700;
                }
            </style>
        </form>
    </div>
</x-app-layout>
