<x-app-layout>
    <x-barcode-scanner/>
    <x-slot name="header">
        <div class="flex items-center">
            <label class="w-max">
                <input id="barcode" type="text" placeholder="Search..."
                       class="mr-4 px-3 py-2 flex border border-gray-300 rounded-md">
            </label>
            <button type="button" data-modal-target="default-modal" data-modal-toggle="default-modal" class="mr-4 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full" id="barcodeScannerBtn"><svg class="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="white" stroke-linejoin="round" stroke-width="2" d="M4 18V8a1 1 0 0 1 1-1h1.5l1.707-1.707A1 1 0 0 1 8.914 5h6.172a1 1 0 0 1 .707.293L17.5 7H19a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1Z"/>
                    <path stroke="white" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"/>
                </svg>
            </button>
        </div>
    </x-slot>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                    <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3">
                                Product name
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Old location
                            </th>
                            <th scope="col" class="px-6 py-3">
                                New location
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Old quantity
                            </th>
                            <th scope="col" class="px-6 py-3">
                                New quantity
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Edited by
                            </th>
                            <th scope="col" class="px-6 py-3">
                               Date of edit
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Show all edits of this product
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($logs as $log)
                            <tr id="{{$log->id}}" class="product-row odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700">
                                <th scope="row"
                                    class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">

                                    <span class="product-name">{{$log->product->productName}}</span>
                                </th>
                                <td id="" class="hidden">
                                    {{$log->product->barcode}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$log->oldLocation}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$log->newLocation}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$log->oldStockQuantity}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$log->newStockQuantity}}
                                </td>
                                <td class="px-6 py-4">
                                     {{$log->employee->name}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$log->created_at->format('d M Y - H:i:s')}}
                                </td>
                                <td class="px-6 py-4">

{{--
                                    <a href="{{url('/dashboard/logs/'.$log->product->id)}}"
                                       class="font-medium text-blue-600 dark:text-blue-500 hover:underline">show edits</a>
--}}
                                </td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</x-app-layout>

<script>
    const searchInput = document.getElementById('barcode');
    const productRows = document.querySelectorAll('.product-row');

    searchInput.addEventListener('input', () => {
        let searchTerm = searchInput.value.trim().toLowerCase();
        let searchTermNumber = Number(searchTerm);

        productRows.forEach((productRow) => {
            const productNameElement = productRow.querySelector('.product-name');
            const productName = productNameElement.textContent.trim().toLowerCase();
            const barcodeElement = productRow.querySelector('td:nth-child(2)'); // Select the 7th td element
            const employeeElement = productRow.querySelector('td:nth-child(7)'); // Select the 7th td element
            const employeeName = employeeElement.textContent.trim().toLowerCase();
            const dateElement = productRow.querySelector('td:nth-child(8)'); // Select the 7th td element
            const dateValue = dateElement.textContent.trim().toLowerCase();

            let barcode;
            if (barcodeElement) { // Check if the element exists
                barcode = Number(barcodeElement.textContent.trim()); // Convert the barcode to a number
            }

            if (productName.includes(searchTerm) || dateValue.includes(searchTerm) || employeeName.includes(searchTerm) || (!isNaN(searchTermNumber) && barcode === searchTermNumber)) { // Compare the barcode number with the search term number
                productRow.style.display = '';
            } else {
                productRow.style.display = 'none';
            }
        });
    });

</script>
