<x-app-layout>
    <x-barcode-scanner/>
    <x-slot name="header">
        <div class="flex items-center">
            <label class="w-max">
                <input id="barcode" type="text" placeholder="Search..."
                       class="mr-4 px-3 py-2 flex border border-gray-300 rounded-md">
            </label>
            <button type="button" data-modal-target="default-modal" data-modal-toggle="default-modal" class="mr-4 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full" id="barcodeScannerBtn"><svg class="w-6 h-6 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="white" stroke-linejoin="round" stroke-width="2" d="M4 18V8a1 1 0 0 1 1-1h1.5l1.707-1.707A1 1 0 0 1 8.914 5h6.172a1 1 0 0 1 .707.293L17.5 7H19a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1Z"/>
                    <path stroke="white" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"/>
                </svg>
            </button>

            <a href="{{url('dashboard/products/add-product')}}"
               class=" px-4 py-2 bg-blue-500 text-white rounded-md bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800">Add
                New Product</a>

            <a href="{{url('dashboard/logs')}}"
               class=" ml-auto px-4 py-2 bg-gray-500 text-white rounded-md bg-gradient-to-r from-gray-500 via-gray-600 to-gray-700 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-gray-300 dark:focus:ring-gray-800">
                Logs
            </a>
        </div>
    </x-slot>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                    <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3">
                                Product name
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Description
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Category
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Price
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Quantity
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Location
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Barcode
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Action
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($products as $product)
                            <tr id="{{$product->id}}" class="product-row odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700">
                                <th scope="row"
                                    class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                    <span class="product-name">{{$product->productName}}</span>
                                </th>
                                <td class="px-6 py-4">
                                    {{$product->description}}
                                </td>
                                <td class="px-6 py-4">
                                    @foreach($categories as $category)
                                        @php
                                            $productCategoryId = $product->categoryId;
                                            $matchingCategory = $categories->where('id', $productCategoryId)->first();
                                        @endphp

                                        @if($matchingCategory)
                                            @php
                                                $categoryName = $matchingCategory->name;
                                            @endphp
                                        @endif
                                    @endforeach
                                    {{-- Display the last category name --}}
                                    {{$categoryName ?? ''}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$product->regularPrice}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$product->stockQuantity}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$product->location}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$product->barcode}}
                                </td>
                                <td class="px-6 py-4">
                                    <a href="{{url('/dashboard/products/edit/'.$product->id)}}"
                                       class="font-medium text-blue-600 dark:text-blue-500 hover:underline">Edit</a>
                                </td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</x-app-layout>

<script>
    const searchInput = document.getElementById('barcode');
    const productRows = document.querySelectorAll('.product-row');

    searchInput.addEventListener('input', () => {
        let searchTerm = searchInput.value.trim().toLowerCase();
        let searchTermNumber = Number(searchTerm);

        productRows.forEach((productRow) => {
            const productNameElement = productRow.querySelector('.product-name');
            const productName = productNameElement.textContent.trim().toLowerCase();
            const barcodeElement = productRow.querySelector('td:nth-child(7)'); // Select the 7th td element
            let barcode = '';
            if (barcodeElement) { // Check if the element exists
                barcode = Number(barcodeElement.textContent.trim()); // Convert the barcode to a number
            }
            if (productName.includes(searchTerm) || (!isNaN(searchTermNumber) && barcode === searchTermNumber)) { // Compare the barcode number with the search term number
                productRow.style.display = '';
            } else {
                productRow.style.display = 'none';
            }
        });
    });

</script>
