<div>
    <!-- Main modal -->
    <div id="list-{{$type}}-modal-{{$id}}" tabindex="-1" aria-hidden="true"
         class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center
         w-full md:inset-0 h-[calc(100%-1rem)] max-h-full cursor-default">
        <div class="relative p-4 w-full max-w-md max-h-full min-w-full min-h-full">
            <!-- Modal content -->
            <div class="relative bg-white rounded-lg shadow dark:bg-gray-700 md:inset-0 h-[calc(100vh-5vh)]">
                <!-- Modal header -->
                <div class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                        {{$type}} list
                    </h3>
                    <button type="button"
                            class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg
                            text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600
                            dark:hover:text-white"
                            data-modal-toggle="list-{{$type}}-modal-{{$id}}">
                        <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                             viewBox="0 0 14 14">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>
                <!-- Modal body -->
                <div>
                    <div class="py-2 text-sm text-gray-700 dark:text-gray-200"
                         aria-labelledby="toggle-{{$type}}-list-modal-button">
                        <input id="search-input-list-{{$type}}"
                               class="block w-[calc(100%-6rem)] px-4 py-2 mb-2 mx-12 text-gray-800 border rounded-md  border-gray-300 focus:outline-none"
                               type="text" placeholder="Search items" autocomplete="on">

                        <ul class="w-[calc(100%-1rem)]">
                            <li class="px-8 py-5 text-lg font-bold dark:text-white">
                                @if($type === "products")
                                    <div class="grid grid-cols-5 text-center align-middle">

                                        <span class="text-start pl-5">Image</span>
                                        <span class="ml-2">Product</span>
                                        <span class="ml-2">Description</span>
                                        <span>Barcode</span>
                                        <span>Stock quantity</span>

                                    </div>
                                @elseif($type === "categories")
                                    <div class="grid grid-cols-2 align-middle">
                                        <span class="ml-2">Categories</span>
                                    </div>
                                @endif
                            </li>
                        </ul>
                        <ul id="itemsList{{$type}}-list" class="max-h-[80vh] overflow-y-scroll">
                            @foreach($data as $item)



                                <li class="px-5">
                                    <div class="grid grid-cols-1">
                                        <label class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">

                                            @if($type === "products")
                                                <div class="grid grid-cols-5 text-center align-middle">
                                                    <img height="90" width="90" src="{{asset('storage/photos/'.$item->picture)}}" alt="{{$item->productName}} picture"/>
                                                    <span class="ml-2">{{$item->productName}}</span>
                                                    <span class="ml-2">{{$item->description}}</span>
                                                    <span>{{$item->barcode}}</span>
                                                    <span>{{$item->stockQuantity}}</span>
                                                    <div class="text-end">

                                                    </div>
                                                </div>
                                            @elseif($type === "categories")
                                                <div class="grid grid-cols-2 align-middle">
                                                    <span class="ml-2">{{$item->name}}</span>
                                                    <div class="text-end">

                                                    </div>
                                                </div>
                                            @endif
                                        </label>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <button data-modal-target="list-{{$type}}-modal-{{$id}}" data-modal-toggle="list-{{$type}}-modal-{{$id}}"
            class="block text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none
                focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600
                dark:hover:bg-blue-700 dark:focus:ring-blue-800"
            type="button" id="toggle-{{$type}}-list-modal-button">
        {{$type}}
    </button>

    <script>
        const searchInputList{{$type}} = document.getElementById('search-input-list-{{$type}}');
        // Add event listener to filter items based on input
        searchInputList{{$type}}.addEventListener('input', () => {
            const searchTerm = searchInputList{{$type}}.value.toLowerCase();
            const items = document.getElementById('itemsList{{$type}}-list').querySelectorAll('li');

            items.forEach((item) => {
                const text = item.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    </script>
</div>
