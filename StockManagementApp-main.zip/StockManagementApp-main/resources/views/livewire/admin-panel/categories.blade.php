<div>

    <div class="p-6 text-gray-900 dark:text-gray-100">
        <div class="block mt-12">
            <div class="grid lg:grid-cols-2">
                <div class="block">
                    <x-categories.adminpanel-add-category-form :categories="$categories"></x-categories.adminpanel-add-category-form>
                </div>
                <div class="block">
                    <form class="flex items-center">
                        <label for="simple-search" class="sr-only">Search</label>
                        <div class="relative w-full">
                            <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                <svg aria-hidden="true" class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="currentColor"
                                     viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd"
                                          d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                                          clip-rule="evenodd"/>
                                </svg>
                            </div>
                            <input wire:model.live="searchCategory" type="text" id="simple-search"
                                   class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 p-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                   placeholder="Search Category..." required="">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

{{--    overview list section--}}
    <div class="grid lg:grid-cols-1" style="margin: 25px">
        <div class="overviewHeader grid grid-cols-2 pl-5">
            <div class="font-bold text-xl">Categories</div>
            <div class="block text-end">
                @if($categories->count()>0)
                <button onclick="ConfirmDelete()" class="mr-7">
                    <i class="fas fa-trash fa-xl"></i>
                </button>
                @endif
            </div>
        </div>
        <div id="dropdownSearch" class="z-10 bg-white rounded-lg shadow w-100 dark:bg-gray-700 mb-3">
            <form id="removeCategory" method="post" action="{{url("dashboard/categories/remove")}}">
                {{--            <input name="test" value="test" type="text">--}}
                @csrf
                <ul wire:loading.class.delay="opacity-70"
                    class="h-96 px-3 py-3 overflow-y-auto text-sm text-gray-700 dark:text-gray-200"
                    aria-labelledby="dropdownSearchButton">
                    @php($x = $y = 0)
                    @forelse($categories as $category)
                        @if(count($category->parentCategories) === 0 || count($category->children) > 0 )
                            <li id="parent-{{$category->name}}">

                                <div class="flex items-center rounded hover:bg-gray-100 dark:hover:bg-gray-600">
                                    <label for="checkbox-item-{{$x}}"
                                           class="w-full ms-2 py-4 text-sm font-extrabold text-gray-900 rounded dark:text-gray-300 cursor-pointer">{{$category->name}}</label>
                                    <a href="{{url('dashboard/categories/edit/'.$category->id)}}" class="hover:underline font-bold px-1 mx-3 rounded">Edit</a>
                                    <input name="category-{{$category->id}}" id="checkbox-item-{{$x}}" type="checkbox"
                                           value="{{$category->id}}"
                                           class="w-4 h-4 mr-5 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 dark:focus:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500">
                                </div>

                                <ul>
                                    @foreach($category->children as $childCategory)
                                        <li id="child-{{$category->name}}">
                                            <div
                                                class="flex items-center rounded hover:bg-gray-100 dark:hover:bg-gray-600">
                                                <label for="checkbox-childItem-{{$y}}"
                                                       class="w-full ms-8 py-4 text-sm font-medium text-gray-900 rounded dark:text-gray-300 cursor-pointer">{{$childCategory->name}}</label>
                                                <a href="{{url('dashboard/categories/edit/'.$childCategory->id)}}" class="hover:underline font-bold px-1 mx-3 rounded">Edit</a>
                                                @php($json = '{"parent" :'.$category->id.', "child":'.$childCategory->id.'}')
                                                <input name="parent-{{$category->id}}-child-{{$childCategory->id}}"
                                                       id="checkbox-childItem-{{$y}}" type="checkbox" value="{{$json}}"
                                                       class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 dark:focus:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500 mr-2">
                                            </div>
                                        </li>
                                        @php($y++)
                                    @endforeach
                                </ul>

                            </li>
                        @elseif((count($category->parentCategories) > 0 && $searchCategory))
                            @foreach($category->parentCategories as $parentCategory)
                                <li id="parent-{{$parentCategory->name}}">

                                    <div class="flex items-center rounded hover:bg-gray-100 dark:hover:bg-gray-600">
                                        <label for="checkbox-item-{{$x}}"
                                               class="w-full ms-2 py-4 text-sm font-extrabold text-gray-900 rounded dark:text-gray-300 cursor-pointer">{{$parentCategory->name}}</label>
                                        <a href="{{url('dashboard/categories/edit/'.$parentCategory->id)}}" class="hover:underline font-bold px-1 mx-3 rounded">Edit</a>
                                        <input name="category-{{$parentCategory->id}}" id="checkbox-item-{{$x}}"
                                               type="checkbox" value="{{$parentCategory->id}}"
                                               class="w-4 h-4  mr-5 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 dark:focus:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500">
                                    </div>

                                    <ul>
                                        <li id="child-{{$category->name}}">
                                            <div
                                                class="flex items-center rounded hover:bg-gray-100 dark:hover:bg-gray-600">
                                                <label for="checkbox-childItem-{{$y}}"
                                                       class="w-full ms-8 py-4 text-sm font-medium text-gray-900 rounded dark:text-gray-300 cursor-pointer">{{$category->name}}</label>
                                                <a href="{{url('dashboard/categories/edit/'.$category->id)}}" class="hover:underline font-bold px-1 mx-3 rounded">Edit</a>
                                                @php($json = '{"parent" :'.$parentCategory->id.', "child":'.$category->id.'}')
                                                <input name="parent-{{$parentCategory->id}}-child-{{$category->id}}"
                                                       id="checkbox-childItem-{{$y}}" type="checkbox" value="{{$json}}"
                                                       class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 dark:focus:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500 mr-2">
                                            </div>
                                        </li>
                                    </ul>

                                </li>
                                @php($y++)
                            @endforeach
                        @endif

                        @php($x++)
                    @empty
                        <li class="text-center text-2xl py-12">No Results</li>
                        @endforelse
                        </ulwire>
            </form>

        </div>
        {{ $categories->links() }}
    </div>
</div>
<script>
    function ConfirmDelete(){
        let confirm = window.confirm("Are you sure that you want to delete?")
        if(confirm){
            document.getElementById("removeCategory").submit();
        }
    }
</script>
