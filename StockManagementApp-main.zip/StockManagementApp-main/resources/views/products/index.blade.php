<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center">
            <label class="w-max">
                <input id="search-input" type="text" placeholder="Search..."
                       class="mr-4 px-3 py-2 flex border border-gray-300 rounded-md">
            </label>
        </div>
    </x-slot>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                    <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3">
                                Product name
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Description
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Category
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Price
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Quantity
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Location
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Barcode
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Action
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($products as $product)
                            <tr class="product-row odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700">
                                <th scope="row"
                                    class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                    <span class="product-name">{{$product->productName}}</span>
                                </th>
                                <td class="px-6 py-4">
                                    {{$product->description}}
                                </td>
                                <td class="px-6 py-4">
                                    @foreach($categories as $category)
                                        @php
                                            $productCategoryId = $product->categoryId;
                                            $matchingCategory = $categories->where('id', $productCategoryId)->first();
                                        @endphp

                                        @if($matchingCategory)
                                            @php
                                                $categoryName = $matchingCategory->name;
                                            @endphp
                                        @endif
                                    @endforeach
                                    {{-- Display the last category name --}}
                                    {{$categoryName ?? ''}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$product->regularPrice}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$product->stockQuantity}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$product->location}}
                                </td>
                                <td class="px-6 py-4">
                                    {{$product->barcode}}
                                </td>
                                <td class="px-6 py-4">
                                    <a href="{{url('/products/edit/'.$product->id)}}"
                                       class="font-medium text-blue-600 dark:text-blue-500 hover:underline">Edit</a>
                                </td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</x-app-layout>

<script>
    // JavaScript to filter products based on the search input
    const searchInput = document.getElementById('search-input');
    const productNameElements = document.querySelectorAll('.product-name');

    searchInput.addEventListener('input', () => {
        const searchTerm = searchInput.value.trim().toLowerCase();

        productNameElements.forEach(productNameElement => {
            const productName = productNameElement.textContent.trim().toLowerCase();

            const parentRow = productNameElement.closest('.product-row');
            if (productName.includes(searchTerm)) {
                parentRow.style.display = '';
            } else {
                parentRow.style.display = 'none';
            }
        });
    });
</script>
