
<x-app-layout>

    <form method="post" action="{{url("/products/edit/".$product->id)}}">

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>
                            {{$error}}
                        </li>
                    @endforeach
                </ul>
            </div>
        @endif
        @csrf
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div style="height: 585px;"
                         class="flex relative overflow-x-auto shadow-md sm:rounded-lg bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <div class="flex-1 w-mt-6 ml-6 ">
                            <div class="mb-2">
                                <label for="productName"
                                       class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Product
                                    Name</label>
                                <input type="text" value="{{$product->productName}}" id="productName" name="productName"
                                       class="bg-gray-200 border border-gray-300 text-gray-900 text-sm rounded-lg
                                           focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5
                                           cursor-not-allowed dark:bg-gray-700 dark:border-gray-600
                                           dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500
                                           dark:focus:border-blue-500"
                                       disabled readonly />
                            </div>
                            <div class="mb-2">
                                <label for="description"
                                       class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Description</label>
                                <input type="text" value=" {{$product->description}}" id="description"
                                       name="description"
                                       class="bg-gray-200 border border-gray-300 text-gray-900 text-sm rounded-lg
                                           focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5
                                           cursor-not-allowed dark:bg-gray-700 dark:border-gray-600
                                           dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500
                                           dark:focus:border-blue-500"
                                       disabled readonly />
                            </div>
                            <div class="grid gap-6 mb-2 md:grid-cols-2">
                                <div>
                                    <label for="brandName"
                                           class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Brand
                                        Name</label>
                                    <input type="text" value="{{$product->brandName}}" id="brandName" name="brandName"
                                           class="bg-gray-200 border border-gray-300 text-gray-900 text-sm rounded-lg
                                           focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5
                                           cursor-not-allowed dark:bg-gray-700 dark:border-gray-600
                                           dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500
                                           dark:focus:border-blue-500"
                                           disabled readonly />
                                </div>
                                <div>
                                    <label for="location"
                                           class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Location</label>
                                    <input type="text" value="{{$product->location}}" id="location" name="location"
                                           class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                           required/>
                                </div>
                                <div>
                                    <label for="barcode"
                                           class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Barcode</label>
                                    <input type="number" value="{{$product->barcode}}" id="barcode" name="barcode"
                                           class="bg-gray-200 border border-gray-300 text-gray-900 text-sm rounded-lg
                                           focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5
                                           cursor-not-allowed dark:bg-gray-700 dark:border-gray-600
                                           dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500
                                           dark:focus:border-blue-500"
                                           disabled readonly />
                                </div>
                                <div>
                                    <label for="stockQuantity"
                                           class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Stock
                                        Quantity</label>
                                    <input type="number" value="{{$product->stockQuantity}}" id="stockQuantity"
                                           name="stockQuantity"
                                           class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                           required/>
                                </div>
                                <div>
                                    <label for="regularPrice"
                                           class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Regular
                                        Price</label>
                                    <input type="number" step="any" value="{{$product->regularPrice}}" id="regularPrice"
                                           name="regularPrice"
                                           class="bg-gray-200 border border-gray-300 text-gray-900 text-sm rounded-lg
                                           focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5
                                           cursor-not-allowed dark:bg-gray-700 dark:border-gray-600
                                           dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500
                                           dark:focus:border-blue-500"
                                           disabled readonly />
                                </div>
                                <div>
                                    <label for="salePrice"
                                           class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Sale
                                        Price</label>
                                    <input type="number" step="any" value="{{$product->salePrice}}" id="salePrice" name="salePrice"
                                           class="bg-gray-200 border border-gray-300 text-gray-900 text-sm rounded-lg
                                           focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5
                                           cursor-not-allowed dark:bg-gray-700 dark:border-gray-600
                                           dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500
                                           dark:focus:border-blue-500"
                                           disabled readonly />
                                </div>
                            </div>
                            <div class="absolute bottom-5 left-5 flex space-x-2">
                                <button id="submitBtn" type="submit"
                                        class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                    Submit
                                </button>
                                <button onclick="history.back()" type="button"
                                        class="focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center" >
                                    Cancel
                                </button>
                            </div>
                        </div>
                        <div class="flex ml-3 px-3 justify-center items-center" style="border-left-width: 1px">
                            <img src="{{asset('storage/photos/'.$product->picture)}}" alt="{{$product->productName}} picture"/>
{{--                            @php(dump(asset('storage/photos/'.$product->picture)))--}}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </form>

</x-app-layout>
